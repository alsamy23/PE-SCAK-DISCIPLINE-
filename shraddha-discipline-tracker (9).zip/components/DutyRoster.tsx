
import React, { useState, useMemo } from 'react';
import { DutyAssignment, DutyDay, DutyType } from '../types';

interface DutyRosterProps {
  roster: DutyAssignment[];
  onUpdateRoster: (updated: DutyAssignment[]) => void;
  isAdmin: boolean;
}

const DutyRoster: React.FC<DutyRosterProps> = ({ roster, onUpdateRoster, isAdmin }) => {
  const [activeDayFilter, setActiveDayFilter] = useState<DutyDay | 'Today'>(() => {
    const day = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date());
    return (['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] as any).includes(day) ? 'Today' : 'Monday';
  });

  // Simplified Modal State: Null means closed, 'new' means adding, Assignment object means editing
  const [activeDuty, setActiveDuty] = useState<DutyAssignment | 'new' | null>(null);
  
  // Local form state for the modal
  const [formValues, setFormValues] = useState({ 
    teacherName: '', 
    phoneNumber: '', 
    day: 'Monday' as DutyDay, 
    type: 'Snack' as DutyType, 
    location: '' 
  });

  const currentDayName = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date()) as DutyDay;

  const filteredRoster = useMemo(() => {
    const day = activeDayFilter === 'Today' ? currentDayName : activeDayFilter;
    return roster.filter(r => r.day === day);
  }, [roster, activeDayFilter, currentDayName]);

  const sendWhatsApp = (duty: DutyAssignment) => {
    const phone = duty.phoneNumber?.replace(/\D/g, '') || '';
    if (!phone) {
      alert(`Phone number missing for ${duty.teacherName}. ${isAdmin ? 'Please click "Update Info" to add it.' : 'Contact Admin to add number.'}`);
      return;
    }
    const message = encodeURIComponent(`Hi ${duty.teacherName}, this is a reminder that you are on ${duty.type} Duty (${duty.location}) today (${duty.day}).`);
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  const handleAllReminders = () => {
    const todayDuties = roster.filter(r => r.day === currentDayName && r.phoneNumber);
    if (todayDuties.length === 0) {
      alert("No duties with phone numbers found for today.");
      return;
    }
    if (confirm(`Open WhatsApp reminder windows for ${todayDuties.length} teachers?`)) {
      todayDuties.forEach((duty, index) => {
        setTimeout(() => sendWhatsApp(duty), index * 1000);
      });
    }
  };

  const openAddModal = () => {
    setFormValues({
      teacherName: '',
      phoneNumber: '',
      day: activeDayFilter === 'Today' ? currentDayName : activeDayFilter,
      type: 'Snack',
      location: ''
    });
    setActiveDuty('new');
  };

  const openEditModal = (duty: DutyAssignment) => {
    setFormValues({
      teacherName: duty.teacherName,
      phoneNumber: duty.phoneNumber || '',
      day: duty.day,
      type: duty.type,
      location: duty.location
    });
    setActiveDuty(duty);
  };

  const handleSave = () => {
    if (!formValues.teacherName || !formValues.location) {
      alert("Please fill in Teacher Name and Location.");
      return;
    }

    if (activeDuty === 'new') {
      const newDuty: DutyAssignment = {
        id: `duty-${Date.now()}`,
        ...formValues
      };
      onUpdateRoster([...roster, newDuty]);
    } else if (activeDuty && typeof activeDuty === 'object') {
      const updated = roster.map(r => 
        r.id === (activeDuty as DutyAssignment).id 
          ? { ...r, ...formValues } 
          : r
      );
      onUpdateRoster(updated);
    }
    setActiveDuty(null);
  };

  const handleDelete = (id: string) => {
    if (confirm('Permanently delete this duty assignment?')) {
      onUpdateRoster(roster.filter(r => r.id !== id));
      setActiveDuty(null);
    }
  };

  return (
    <div className="space-y-6 animate-slide-in-fade relative">
      {/* Header Dashboard */}
      <div className="bg-indigo-900 text-white p-10 rounded-[2.5rem] shadow-2xl flex flex-col md:flex-row justify-between items-center gap-8 border-b-[12px] border-indigo-700 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
        <div className="flex items-center gap-8 relative z-10">
          <div className="bg-white/10 p-5 rounded-3xl border border-white/10 backdrop-blur-md">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-indigo-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
             </svg>
          </div>
          <div>
            <h2 className="text-3xl font-black uppercase tracking-tight">Duty Management</h2>
            <p className="text-indigo-200 text-sm font-black uppercase tracking-widest mt-1 flex items-center">
              <span className="w-2 h-2 bg-emerald-400 rounded-full mr-2 animate-pulse"></span>
              {currentDayName} Schedule
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-4 relative z-10 justify-center">
          {isAdmin && (
            <button 
              onClick={openAddModal}
              className="bg-white text-indigo-900 px-8 py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg active:scale-95 flex items-center hover:bg-slate-50"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
              </svg>
              Add New Duty
            </button>
          )}
          <button 
            onClick={handleAllReminders}
            className="bg-emerald-500 hover:bg-emerald-400 text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-[0_10px_20px_rgba(16,185,129,0.3)] active:scale-95 flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
            Send WhatsApp Blast
          </button>
        </div>
      </div>

      {/* Unified Add/Edit Modal */}
      {activeDuty !== null && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[2.5rem] shadow-2xl p-10 w-full max-w-lg border border-slate-200 animate-slide-in-fade">
             <div className="flex justify-between items-center mb-8">
               <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">
                  {activeDuty === 'new' ? 'Create New Entry' : 'Update Teacher Info'}
               </h3>
               {activeDuty !== 'new' && (
                 <button onClick={() => handleDelete((activeDuty as DutyAssignment).id)} className="text-rose-500 p-2 hover:bg-rose-50 rounded-xl transition-all">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                 </button>
               )}
             </div>
             <div className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 ml-1">Assign Day</label>
                    <select 
                      value={formValues.day} 
                      onChange={e => setFormValues(p => ({...p, day: e.target.value as DutyDay}))} 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-bold appearance-none transition-all"
                    >
                      {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 ml-1">Duty Type</label>
                    <select 
                      value={formValues.type} 
                      onChange={e => setFormValues(p => ({...p, type: e.target.value as DutyType}))} 
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-bold appearance-none transition-all"
                    >
                      <option value="Snack">Snack</option>
                      <option value="Lunch">Lunch</option>
                      <option value="Dispersal">Dispersal</option>
                    </select>
                  </div>
                </div>
                <div>
                   <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 ml-1">Physical Location</label>
                   <input 
                    value={formValues.location} 
                    onChange={e => setFormValues(p => ({...p, location: e.target.value}))} 
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium transition-all" 
                    placeholder="e.g. Ground Floor / Canteen" 
                   />
                </div>
                <div>
                   <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 ml-1">Staff Member Name</label>
                   <input 
                    value={formValues.teacherName} 
                    onChange={e => setFormValues(p => ({...p, teacherName: e.target.value}))} 
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-black transition-all" 
                    placeholder="Teacher Name" 
                   />
                </div>
                <div>
                   <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 ml-1 text-emerald-600">WhatsApp Number (e.g. 91984...)</label>
                   <input 
                    value={formValues.phoneNumber} 
                    onChange={e => setFormValues(p => ({...p, phoneNumber: e.target.value}))} 
                    className="w-full px-5 py-3.5 bg-emerald-50 border border-emerald-100 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-mono font-bold text-emerald-900 transition-all" 
                    placeholder="91XXXXXXXXXX" 
                   />
                </div>
             </div>
             <div className="flex gap-4 mt-10">
                <button onClick={() => setActiveDuty(null)} className="flex-1 px-4 py-4 text-slate-400 font-black text-xs uppercase hover:bg-slate-50 rounded-2xl transition-all">Cancel</button>
                <button onClick={handleSave} className="flex-2 bg-indigo-600 text-white px-10 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all active:scale-95">
                  {activeDuty === 'new' ? 'Confirm Addition' : 'Update Assignment'}
                </button>
             </div>
          </div>
        </div>
      )}

      <div className="bg-white p-8 rounded-[3rem] shadow-lg border border-slate-100">
        {/* Day Filters */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-10 gap-6">
          <div className="flex bg-slate-100 p-1.5 rounded-2xl w-full lg:w-auto overflow-x-auto no-scrollbar shadow-inner">
            {(['Today', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] as const).map((day) => (
              <button
                key={day}
                onClick={() => setActiveDayFilter(day)}
                className={`px-8 py-3.5 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all whitespace-nowrap ${
                  activeDayFilter === day 
                    ? 'bg-white shadow-md text-indigo-600' 
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {day}
              </button>
            ))}
          </div>
          
          {isAdmin && (
             <button onClick={openAddModal} className="text-[10px] font-black uppercase text-indigo-600 bg-indigo-50 px-4 py-2 rounded-full border border-indigo-100 hover:bg-indigo-100 transition-all">
                + Quick Entry
             </button>
          )}
        </div>

        {/* Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredRoster.map((duty) => (
            <div key={duty.id} className="group relative bg-slate-50 border border-slate-200 rounded-[2rem] p-8 transition-all hover:bg-white hover:shadow-2xl hover:border-indigo-100 flex flex-col h-full">
              <div className="flex justify-between items-start mb-6">
                <span className={`text-[9px] font-black uppercase px-4 py-2 rounded-full ${
                  duty.type === 'Snack' ? 'bg-amber-100 text-amber-700' :
                  duty.type === 'Lunch' ? 'bg-indigo-100 text-indigo-700' :
                  'bg-emerald-100 text-emerald-700'
                }`}>
                  {duty.type} Duty
                </span>
                {isAdmin && (
                  <button 
                    onClick={() => openEditModal(duty)}
                    className="p-2 text-slate-300 hover:text-indigo-600 transition-all bg-white rounded-full shadow-sm border border-slate-100"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                  </button>
                )}
              </div>

              <div className="flex-1">
                <h4 className="text-2xl font-black text-slate-800 mb-2 leading-tight group-hover:text-indigo-900 transition-colors">{duty.teacherName}</h4>
                <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-8 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 text-indigo-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /></svg>
                  {duty.location}
                </p>
              </div>

              <div className="space-y-4 pt-6 border-t border-slate-200 mt-auto">
                <div className="flex items-center justify-between">
                  <div className="text-[10px] font-black uppercase tracking-widest flex items-center">
                    {duty.phoneNumber ? (
                      <span className="text-emerald-500 flex items-center bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2"></span>
                        Contact set
                      </span>
                    ) : (
                      <span className="text-slate-300 italic">No Number</span>
                    )}
                  </div>
                  <button 
                    onClick={() => sendWhatsApp(duty)}
                    className="bg-indigo-600 text-white p-4 rounded-2xl transition-all shadow-lg hover:bg-emerald-600 active:scale-90"
                    title="Send Individual Reminder"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                  </button>
                </div>

                {isAdmin && (
                  <button 
                    onClick={() => openEditModal(duty)}
                    className="w-full py-3 bg-white hover:bg-indigo-600 text-indigo-600 hover:text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border border-indigo-100 shadow-sm"
                  >
                    Update Info / Phone
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Master Data Archive */}
        <div className="mt-20 bg-slate-900 rounded-[3.5rem] p-12 border border-slate-800 shadow-2xl relative overflow-hidden">
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-500/5 rounded-full -mb-48 -mr-48 blur-3xl pointer-events-none"></div>
          <div className="flex justify-between items-center mb-10 relative z-10">
            <h3 className="text-sm font-black text-indigo-300 uppercase tracking-widest flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>
              Weekly Master Roster
            </h3>
          </div>
          <div className="overflow-x-auto rounded-[2rem] border border-white/10 bg-white/5 relative z-10">
            <table className="min-w-full divide-y divide-white/10">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-8 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Schedule Day</th>
                  <th className="px-8 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Duty Category</th>
                  <th className="px-8 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Campus Area</th>
                  <th className="px-8 py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Teacher Assignment</th>
                  <th className="px-8 py-6 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest">WhatsApp ID</th>
                  {isAdmin && <th className="px-8 py-6 text-center text-[10px] font-black text-slate-400 uppercase tracking-widest">Control</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {roster.map((r) => (
                  <tr key={r.id} className={`transition-all hover:bg-white/5 ${r.day === currentDayName ? 'bg-indigo-500/10' : ''}`}>
                    <td className="px-8 py-6 whitespace-nowrap text-xs font-black text-indigo-300">{r.day}</td>
                    <td className="px-8 py-6 whitespace-nowrap text-xs font-bold text-white uppercase tracking-tighter">{r.type}</td>
                    <td className="px-8 py-6 whitespace-nowrap text-xs font-medium text-slate-400 italic opacity-60">{r.location}</td>
                    <td className="px-8 py-6 whitespace-nowrap text-sm font-black text-white">{r.teacherName}</td>
                    <td className="px-8 py-6 whitespace-nowrap text-center text-xs font-mono text-slate-500 font-bold tracking-widest">{r.phoneNumber || '---'}</td>
                    {isAdmin && (
                      <td className="px-8 py-6 whitespace-nowrap text-center">
                        <div className="flex justify-center gap-4">
                           <button onClick={() => openEditModal(r)} className="text-indigo-400 hover:text-white transition-all text-[10px] font-black uppercase tracking-widest bg-indigo-500/10 px-4 py-2 rounded-lg">Update</button>
                           <button onClick={() => handleDelete(r.id)} className="text-rose-400 hover:text-rose-300 transition-all">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                           </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DutyRoster;
