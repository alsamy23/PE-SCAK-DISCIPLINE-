
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (identifier: string, isAdmin: boolean) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [loginMode, setLoginMode] = useState<'teacher' | 'admin'>('teacher');
  const [email, setEmail] = useState('');
  const [adminUser, setAdminUser] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [error, setError] = useState('');

  // Default Admin Credentials
  const ADMIN_CREDENTIALS = {
    user: 'admin',
    pass: 'shraddha@2025'
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (loginMode === 'teacher') {
      if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
        setError('Please enter a valid teacher email address.');
        return;
      }
      onLogin(email, false);
    } else {
      if (adminUser === ADMIN_CREDENTIALS.user && adminPass === ADMIN_CREDENTIALS.pass) {
        onLogin('Administrator', true);
      } else {
        setError('Invalid Admin credentials.');
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center space-x-3 mb-8">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-indigo-600" viewBox="0 0 20 20" fill="currentColor">
                <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd" />
            </svg>
            <h1 className="text-3xl font-black text-slate-800 tracking-tight uppercase">
                Shraddha <span className="text-indigo-600">Tracker</span>
            </h1>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
          <div className="flex border-b border-slate-100">
            <button 
              onClick={() => setLoginMode('teacher')}
              className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all ${loginMode === 'teacher' ? 'bg-white text-indigo-600 border-b-2 border-indigo-600' : 'bg-slate-50 text-slate-400'}`}
            >
              Teacher Access
            </button>
            <button 
              onClick={() => setLoginMode('admin')}
              className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all ${loginMode === 'admin' ? 'bg-white text-rose-600 border-b-2 border-rose-600' : 'bg-slate-50 text-slate-400'}`}
            >
              Admin Portal
            </button>
          </div>

          <div className="p-8">
            <div className="text-center mb-8">
              <h2 className="text-xl font-bold text-slate-800">
                {loginMode === 'teacher' ? 'School Staff Login' : 'Administrative Secure Login'}
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                {loginMode === 'teacher' ? 'Enter your email to start tracking.' : 'Restricted area. Credentials required.'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {loginMode === 'teacher' ? (
                <div>
                  <label htmlFor="email" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                    Staff Email Address
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder-slate-300"
                    placeholder="teacher@shraddhaschool.com"
                  />
                </div>
              ) : (
                <>
                  <div>
                    <label htmlFor="adminUser" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                      Admin Username
                    </label>
                    <input
                      id="adminUser"
                      type="text"
                      required
                      value={adminUser}
                      onChange={(e) => setAdminUser(e.target.value)}
                      className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all"
                      placeholder="Username"
                    />
                  </div>
                  <div>
                    <label htmlFor="adminPass" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                      Admin Password
                    </label>
                    <input
                      id="adminPass"
                      type="password"
                      required
                      value={adminPass}
                      onChange={(e) => setAdminPass(e.target.value)}
                      className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all"
                      placeholder="••••••••"
                    />
                  </div>
                </>
              )}
              
              {error && (
                <div className="p-3 bg-rose-50 text-rose-600 text-xs font-bold rounded-lg border border-rose-100 animate-pulse">
                  {error}
                </div>
              )}

              <button
                type="submit"
                className={`w-full flex justify-center py-4 px-4 rounded-xl shadow-lg text-sm font-black text-white uppercase tracking-widest transition-all active:scale-[0.98] ${
                  loginMode === 'teacher' ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-slate-900 hover:bg-black'
                }`}
              >
                Log Into System
              </button>
            </form>
          </div>
        </div>
        
        <p className="text-center mt-8 text-slate-400 text-[10px] font-bold uppercase tracking-widest">
          Shraddha Education Management System &bull; v2.0
        </p>
      </div>
    </div>
  );
};

export default Login;
