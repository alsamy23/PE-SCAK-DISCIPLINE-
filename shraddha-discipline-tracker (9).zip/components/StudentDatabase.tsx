
import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { Student, DisciplineRecord, FitnessRecord } from '../types';

interface StudentDatabaseProps {
  students: Student[];
  disciplineRecords: DisciplineRecord[];
  fitnessRecords: FitnessRecord[];
  onImport: (students: Student[]) => void;
  onClear: () => void;
  onFullRestore: (data: any) => void;
}

const StudentDatabase: React.FC<StudentDatabaseProps> = ({ 
  students, 
  disciplineRecords, 
  fitnessRecords, 
  onImport, 
  onClear,
  onFullRestore
}) => {
  const [isImporting, setIsImporting] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    const reader = new FileReader();

    reader.onload = (evt) => {
      try {
        const data = evt.target?.result;
        if (!data) throw new Error("Failed to read file data");

        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[];

        if (!jsonData || jsonData.length === 0) {
          throw new Error("The Excel file seems to be empty.");
        }

        const importedStudents: Student[] = jsonData.map((row, index) => {
          const name = row['Name of the Student'] || row.Name || row.name || row.STUDENT || '';
          const className = row.Grade || row.Class || row.class || '';
          const section = row.Section || row.SEC || row.sec || '';
          const enrollmentNo = row['Enrollment No'] || row['Enroll No'] || row['ID'] || row['Enrollment'] || row['Student ID'] || '';

          return {
            id: `std-${Date.now()}-${index}`,
            name: name.toString().trim(),
            class: className.toString().trim(),
            section: section.toString().trim(),
            enrollmentNo: enrollmentNo.toString().trim()
          };
        }).filter(s => s.name !== '');

        if (importedStudents.length === 0) {
          throw new Error("No students found. Check your Excel headers.");
        }

        onImport(importedStudents);
      } catch (err: any) {
        alert(`Error: ${err.message}`);
      } finally {
        setIsImporting(false);
        e.target.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleFullExport = () => {
    const backupData = {
      students,
      disciplineRecords,
      fitnessRecords,
      exportDate: new Date().toISOString(),
      version: "1.0"
    };
    
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Shraddha_System_Backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFullRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm('Warning: This will overwrite your current browser data with the backup file. Continue?')) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = JSON.parse(evt.target?.result as string);
        if (!data.students || !data.disciplineRecords) {
          throw new Error("Invalid backup file format.");
        }
        onFullRestore(data);
      } catch (err) {
        alert("Failed to restore backup. Please ensure it is a valid backup file.");
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-8">
      {/* Top Action Bar */}
      <div className="bg-white p-8 rounded-xl shadow-lg border border-slate-200">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Master Student Roster</h2>
            <div className="flex items-center mt-1">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 mr-2"></span>
              <p className="text-slate-500 text-sm">Active Database: {students.length} students</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <label className={`cursor-pointer ${isImporting ? 'bg-indigo-400' : 'bg-indigo-600 hover:bg-indigo-700'} text-white px-4 py-2 rounded-lg font-black text-xs uppercase tracking-widest transition-all shadow-md flex items-center`}>
              <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 mr-2 ${isImporting ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
              {isImporting ? 'Importing...' : 'Bulk Student Import'}
              <input type="file" className="hidden" accept=".xlsx, .xls, .csv" onChange={handleFileUpload} disabled={isImporting} />
            </label>
            <button onClick={() => onClear()} className="px-4 py-2 text-rose-500 hover:text-rose-700 text-xs font-black uppercase tracking-widest transition-all">
              Clear Roster
            </button>
          </div>
        </div>

        {students.length === 0 ? (
          <div className="border-2 border-dashed border-slate-200 rounded-xl p-12 text-center bg-slate-50/50">
            <p className="text-slate-400 text-xs font-medium uppercase tracking-widest">No Students Imported Yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 max-h-[400px] overflow-y-auto p-1 custom-scrollbar">
            {students.map((student) => (
              <div key={student.id} className="bg-white p-3 rounded-lg border border-slate-100 flex flex-col group hover:border-indigo-200 transition-all">
                <p className="font-bold text-slate-800 truncate text-sm">{student.name}</p>
                <div className="flex justify-between items-center mt-1">
                  <p className="text-[10px] font-black text-indigo-400 uppercase">{student.class} - {student.section}</p>
                  {student.enrollmentNo && (
                    <p className="text-[9px] font-mono text-slate-400">{student.enrollmentNo}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Data Management & Backup Section */}
      <div className="bg-slate-900 text-white p-8 rounded-xl shadow-xl border border-slate-800">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-6">
          <div>
            <h3 className="text-xl font-black uppercase tracking-widest text-indigo-400">System Storage & Sync</h3>
            <p className="text-slate-400 text-sm mt-1">Manage your complete school database backup files.</p>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={handleFullExport}
              className="bg-indigo-500 hover:bg-indigo-400 text-white px-6 py-3 rounded-lg font-black text-xs uppercase tracking-widest flex items-center transition-all shadow-lg active:scale-95"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
              </svg>
              Export System Backup
            </button>
            <label className="bg-slate-800 hover:bg-slate-700 text-indigo-300 px-6 py-3 rounded-lg font-black text-xs uppercase tracking-widest flex items-center cursor-pointer transition-all border border-slate-700">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
              Restore System
              <input type="file" className="hidden" accept=".json" onChange={handleFullRestore} />
            </label>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
           <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Discipline Entries</p>
              <p className="text-3xl font-black text-white">{disciplineRecords.length}</p>
              <p className="text-[10px] text-slate-400 mt-2 italic">Stored locally in this browser</p>
           </div>
           <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Fitness Records</p>
              <p className="text-3xl font-black text-white">{fitnessRecords.length}</p>
              <p className="text-[10px] text-slate-400 mt-2 italic">Stored locally in this browser</p>
           </div>
           <div className="bg-indigo-900/30 p-4 rounded-lg border border-indigo-500/30">
              <p className="text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-2">Sync Status</p>
              <div className="flex items-center text-emerald-400 font-black text-sm">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Local Storage Active
              </div>
              <p className="text-[10px] text-slate-400 mt-2">Export a backup to save permanently.</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDatabase;
