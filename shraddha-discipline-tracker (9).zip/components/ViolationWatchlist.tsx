
import React, { useMemo, useState } from 'react';
import { DisciplineRecord, Restriction, Student } from '../types';

interface ViolationWatchlistProps {
  records: DisciplineRecord[];
  restrictions: Restriction[];
  students: Student[];
  onSaveRestriction: (restr: Restriction) => void;
  onDeleteRestriction: (id: string) => void;
  currentUserEmail: string;
}

const ViolationWatchlist: React.FC<ViolationWatchlistProps> = ({ 
  records, 
  restrictions, 
  students, 
  onSaveRestriction, 
  onDeleteRestriction,
  currentUserEmail
}) => {
  const [showAddRestr, setShowAddRestr] = useState(false);
  const [selectedStudentName, setSelectedStudentName] = useState('');
  const [restrDays, setRestrDays] = useState('3');
  const [restrReason, setRestrReason] = useState('Repeated violations');
  const [timeFrame, setTimeFrame] = useState<'weekly' | 'monthly' | 'all'>('all');

  // Calculate repeated offenders with timeframe filter
  const offenderStats = useMemo(() => {
    const stats: Record<string, { count: number, class: string, grade: string, details: DisciplineRecord[] }> = {};
    
    const now = new Date();
    let filterDate = new Date(0); // Default to beginning of time
    
    if (timeFrame === 'weekly') {
      filterDate = new Date(now.setDate(now.getDate() - 7));
    } else if (timeFrame === 'monthly') {
      filterDate = new Date(now.setMonth(now.getMonth() - 1));
    }

    records.forEach(rec => {
      const recordDate = new Date(rec.date);
      if (recordDate >= filterDate) {
        const key = `${rec.studentName}|${rec.grade}`;
        if (!stats[key]) {
          stats[key] = { count: 0, class: rec.studentName, grade: rec.grade, details: [] };
        }
        stats[key].count += 1;
        stats[key].details.push(rec);
      }
    });

    return Object.values(stats)
      .filter(s => s.count >= 3)
      .sort((a, b) => b.count - a.count);
  }, [records, timeFrame]);

  const activeRestrictions = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    return restrictions.filter(r => r.endDate >= today);
  }, [restrictions]);

  const handleAddRestriction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentName) return;

    const student = students.find(s => s.name === selectedStudentName);
    const start = new Date();
    const end = new Date();
    end.setDate(start.getDate() + parseInt(restrDays));

    const newRestr: Restriction = {
      id: `res-${Date.now()}`,
      studentName: selectedStudentName,
      studentClass: student?.class || '',
      studentSection: student?.section || '',
      startDate: start.toISOString().split('T')[0],
      endDate: end.toISOString().split('T')[0],
      reason: restrReason,
      assignedBy: currentUserEmail
    };

    onSaveRestriction(newRestr);
    setShowAddRestr(false);
    setSelectedStudentName('');
  };

  return (
    <div className="space-y-8 animate-slide-in-fade">
      {/* Active Restrictions Bar */}
      <div className="bg-rose-600 text-white p-6 rounded-2xl shadow-xl flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="bg-white/20 p-3 rounded-xl">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
             </svg>
          </div>
          <div>
            <h2 className="text-xl font-black uppercase tracking-widest">No-Play List</h2>
            <p className="text-rose-100 text-sm">Students restricted from Play Periods today.</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="text-center">
            <span className="block text-3xl font-black">{activeRestrictions.length}</span>
            <span className="text-[10px] font-black uppercase text-rose-200">Restricted</span>
          </div>
          <button 
            onClick={() => setShowAddRestr(true)}
            className="bg-white text-rose-600 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-rose-50 transition-all shadow-lg"
          >
            Restrict Student
          </button>
        </div>
      </div>

      {showAddRestr && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form onSubmit={handleAddRestriction} className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight mb-6">Assign Restriction</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">Select Student</label>
                <select 
                  value={selectedStudentName} 
                  onChange={(e) => setSelectedStudentName(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-rose-500"
                  required
                >
                  <option value="">-- Choose Student --</option>
                  {students.map(s => <option key={s.id} value={s.name}>{s.name} ({s.class}{s.section})</option>)}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">Duration (Days)</label>
                <input 
                  type="number" 
                  value={restrDays} 
                  onChange={(e) => setRestrDays(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-rose-500"
                  min="1"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">Reason</label>
                <textarea 
                  value={restrReason} 
                  onChange={(e) => setRestrReason(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-rose-500"
                  rows={2}
                />
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button type="button" onClick={() => setShowAddRestr(false)} className="flex-1 px-4 py-3 text-slate-400 font-black text-xs uppercase">Cancel</button>
              <button type="submit" className="flex-1 bg-rose-600 text-white px-4 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg">Confirm Ban</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Watchlist Section */}
        <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-black text-slate-800 uppercase tracking-widest flex items-center">
              <span className="w-2 h-6 bg-amber-500 rounded-full mr-3"></span>
              Repeated Offenders (3+)
            </h3>
            <div className="flex bg-slate-100 p-1 rounded-lg">
              {(['all', 'monthly', 'weekly'] as const).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeFrame(tf)}
                  className={`px-3 py-1 text-[10px] font-black uppercase rounded-md transition-all ${timeFrame === tf ? 'bg-white shadow text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
          
          {offenderStats.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs font-bold uppercase tracking-widest bg-slate-50 rounded-xl border-2 border-dashed border-slate-200">
              Clean Records! No repeated violations found in this period.
            </div>
          ) : (
            <div className="space-y-4">
              {offenderStats.map((offender, idx) => (
                <div key={idx} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center group hover:bg-white hover:shadow-md transition-all">
                  <div>
                    <p className="font-black text-slate-800">{offender.class}</p>
                    <p className="text-[10px] font-black text-amber-600 uppercase">Grade {offender.grade}</p>
                  </div>
                  <div className="text-right">
                    <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-black">
                      {offender.count} VIOLATIONS
                    </span>
                    <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold">Watchlist Item</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Current Restrictions List */}
        <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200">
          <h3 className="text-lg font-black text-slate-800 uppercase tracking-widest mb-6 flex items-center">
            <span className="w-2 h-6 bg-rose-500 rounded-full mr-3"></span>
            Restriction Management
          </h3>
          
          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
            {restrictions.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs font-black uppercase border-2 border-dashed border-slate-200 rounded-xl">No history found.</p>
            ) : (
              [...restrictions].sort((a,b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime()).map((res) => (
                <div key={res.id} className="p-4 rounded-xl border border-slate-100 bg-white shadow-sm relative overflow-hidden group">
                  <div className={`absolute left-0 top-0 bottom-0 w-1 ${new Date(res.endDate) >= new Date() ? 'bg-rose-500' : 'bg-slate-300'}`}></div>
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-black text-slate-800">{res.studentName}</p>
                      <p className="text-[10px] font-black text-slate-500 uppercase">{res.studentClass} {res.studentSection} • Assigned by {res.assignedBy.split('@')[0]}</p>
                      <div className="mt-2 text-xs text-slate-600 italic">"{res.reason}"</div>
                    </div>
                    <button 
                      onClick={() => onDeleteRestriction(res.id)}
                      className="text-slate-300 hover:text-rose-500 p-2 transition-colors"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                      Ends: <span className="text-slate-700">{res.endDate}</span>
                    </div>
                    {new Date(res.endDate) >= new Date() ? (
                      <span className="text-[10px] font-black bg-rose-50 text-rose-600 px-2 py-0.5 rounded border border-rose-100 uppercase">Current</span>
                    ) : (
                      <span className="text-[10px] font-black bg-slate-50 text-slate-400 px-2 py-0.5 rounded uppercase">Expired</span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ViolationWatchlist;
