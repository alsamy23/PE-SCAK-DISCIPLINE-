
import React, { useState, useMemo, useEffect } from 'react';
import { FitnessRecord } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { analyzeClassFitness } from '../services/fitnessAiService';

interface FitnessAnalysisModalProps {
  records: FitnessRecord[];
  onClose: () => void;
  title: string;
}

const FitnessAnalysisModal: React.FC<FitnessAnalysisModalProps> = ({ records, onClose, title }) => {
  const [activeTab, setActiveTab] = useState<'compare' | 'reports'>('compare');
  const [aiInsight, setAiInsight] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const metricsList = [
    { key: 'speed50m', label: 'Speed' },
    { key: 'endurance600m', label: 'Endurance' },
    { key: 'strength', label: 'Strength' },
    { key: 'flexibility', label: 'Flex' },
    { key: 'curlsUp', label: 'Curls' },
    { key: 'gameSkill1', label: 'Skill 1' },
    { key: 'gameSkill2', label: 'Skill 2' },
    { key: 'discipline', label: 'Disc' }
  ];

  const classAverages = useMemo(() => {
    if (records.length === 0) return [];
    
    return metricsList.map(m => {
      const baselineAvg = records.reduce((acc, r) => acc + (r.baseline as any)[m.key], 0) / records.length;
      const finalAvg = records.reduce((acc, r) => acc + (r.final ? (r.final as any)[m.key] : 0), 0) / records.filter(r => r.final).length || 0;
      return {
        metric: m.label,
        baseline: parseFloat(baselineAvg.toFixed(2)),
        final: parseFloat(finalAvg.toFixed(2))
      };
    });
  }, [records]);

  const handleGenerateAiInsight = async () => {
    setIsAiLoading(true);
    const insight = await analyzeClassFitness(classAverages);
    setAiInsight(insight);
    setIsAiLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md flex items-center justify-center z-[100] p-4 print:p-0">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-6xl max-h-[95vh] flex flex-col animate-slide-in-fade border border-slate-200 print:shadow-none print:border-none print:rounded-none print:max-h-full">
        
        {/* Header - Hidden on Print */}
        <div className="px-8 py-6 border-b flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white sticky top-0 z-10 print:hidden">
          <div>
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">{title}</h2>
            <p className="text-xs font-black text-indigo-500 uppercase tracking-widest mt-1">
              Analyzing {records.length} Student Records
            </p>
          </div>
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button 
              onClick={() => setActiveTab('compare')}
              className={`px-4 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${activeTab === 'compare' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}
            >
              Compare Data
            </button>
            <button 
              onClick={() => setActiveTab('reports')}
              className={`px-4 py-2 text-[10px] font-black uppercase rounded-lg transition-all ${activeTab === 'reports' ? 'bg-white shadow text-indigo-600' : 'text-slate-500'}`}
            >
              Batch Reports
            </button>
          </div>
          <div className="flex gap-2">
             <button onClick={() => window.print()} className="bg-slate-800 text-white p-2.5 rounded-xl hover:bg-black">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
             </button>
             <button onClick={onClose} className="p-2.5 bg-slate-100 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-xl transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
             </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 bg-slate-50/30 print:bg-white print:p-0">
          
          {activeTab === 'compare' ? (
            <div className="space-y-8 animate-slide-in-fade print:hidden">
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center">
                  <span className="w-2 h-2 bg-indigo-500 rounded-full mr-2"></span>
                  Class Metric Averages (Baseline vs Final)
                </h3>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={classAverages}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="metric" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 900, fill: '#64748b' }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }} />
                      <Tooltip 
                        cursor={{ fill: '#f8fafc' }}
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} 
                      />
                      <Legend verticalAlign="top" align="right" iconType="circle" wrapperStyle={{ paddingBottom: '20px', fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }} />
                      <Bar name="Baseline" dataKey="baseline" fill="#6366f1" radius={[4, 4, 0, 0]} />
                      <Bar name="Final" dataKey="final" fill="#10b981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-indigo-900 rounded-3xl p-8 text-white shadow-xl relative overflow-hidden">
                <div className="absolute right-0 top-0 opacity-10 pointer-events-none">
                  <svg className="h-64 w-64 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L1 21h22L12 2zm0 3.45l8.15 14.1H3.85L12 5.45zM11 10v4h2v-4h-2zm0 6v2h2v-2h-2z" /></svg>
                </div>
                <div className="relative z-10">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xs font-black uppercase tracking-widest text-indigo-300">Gemini AI Class Insights</h3>
                    <button 
                      onClick={handleGenerateAiInsight}
                      disabled={isAiLoading}
                      className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isAiLoading ? 'Analyzing...' : 'Refresh AI Analysis'}
                    </button>
                  </div>
                  {aiInsight ? (
                    <p className="text-lg font-bold leading-relaxed italic text-indigo-50">"{aiInsight}"</p>
                  ) : (
                    <div className="py-4 border-2 border-dashed border-indigo-700 rounded-2xl text-center">
                      <p className="text-indigo-300 text-sm italic">Click button to generate sports science insights for this class.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-slide-in-fade print:grid-cols-2 print:gap-4 print:block">
              {records.map((r, i) => (
                <div key={r.rollNo + r.name + i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm print:shadow-none print:border print:mb-6 print:break-inside-avoid">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="font-black text-slate-800 text-sm uppercase">{r.name}</h4>
                      <p className="text-[9px] font-black text-slate-400 uppercase">Roll No: {r.rollNo} • {r.class} {r.section}</p>
                    </div>
                    <div className={`px-2 py-1 rounded-lg text-[10px] font-black ${
                      (r.final?.total || 0) >= (r.baseline.total) ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                    }`}>
                      {r.final ? `${r.final.total - r.baseline.total >= 0 ? '+' : ''}${r.final.total - r.baseline.total} PTS` : 'NO FINAL TEST'}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-slate-50 p-2 rounded-xl text-center border border-slate-100">
                      <p className="text-[8px] font-black text-slate-400 uppercase">Baseline</p>
                      <p className="text-lg font-black text-slate-700">{r.baseline.total}</p>
                      <span className="text-[8px] font-black text-indigo-500">GRADE {r.baseline.grade}</span>
                    </div>
                    <div className="bg-indigo-50 p-2 rounded-xl text-center border border-indigo-100">
                      <p className="text-[8px] font-black text-indigo-400 uppercase">Final</p>
                      <p className="text-lg font-black text-indigo-700">{r.final?.total || '---'}</p>
                      <span className="text-[8px] font-black text-emerald-500">GRADE {r.final?.grade || '-'}</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[9px]">
                      <span className="text-slate-400 font-bold uppercase">Speed</span>
                      <span className="font-black">{r.baseline.speed50m} <span className="text-emerald-500">→ {r.final?.speed50m || '-'}</span></span>
                    </div>
                    <div className="flex justify-between text-[9px]">
                      <span className="text-slate-400 font-bold uppercase">Endurance</span>
                      <span className="font-black">{r.baseline.endurance600m} <span className="text-emerald-500">→ {r.final?.endurance600m || '-'}</span></span>
                    </div>
                    <div className="flex justify-between text-[9px]">
                      <span className="text-slate-400 font-bold uppercase">Strength</span>
                      <span className="font-black">{r.baseline.strength} <span className="text-emerald-500">→ {r.final?.strength || '-'}</span></span>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-dashed border-slate-100">
                    <p className="text-[9px] text-slate-500 italic truncate">"{r.final?.remark || r.baseline.remark || 'Showing consistent participation.'}"</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FitnessAnalysisModal;
