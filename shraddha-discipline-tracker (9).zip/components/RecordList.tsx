
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { DisciplineRecord, Restriction } from '../types';
import RecordCard from './RecordCard';
import * as XLSX from 'xlsx';
import ReportModal from './ReportModal';
import Pagination from './Pagination';

interface RecordListProps {
  records: DisciplineRecord[];
  restrictions: Restriction[];
}

const ITEMS_PER_PAGE = 5;

const RecordList: React.FC<RecordListProps> = ({ records, restrictions }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [reportRecords, setReportRecords] = useState<DisciplineRecord[]>([]);
  const [reportDuration, setReportDuration] = useState<'weekly' | 'monthly' | 'custom'>('weekly');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const prevRecordsLength = useRef(records.length);

  // Identify high-frequency violators for real-time highlighting
  const violators = useMemo(() => {
    const counts: Record<string, number> = {};
    records.forEach(r => {
      counts[r.studentName] = (counts[r.studentName] || 0) + 1;
    });
    return counts;
  }, [records]);

  // Map of (Student + Violation + Date) to list of unique teachers who reported it
  const consensusMap = useMemo(() => {
    const map: Record<string, Set<string>> = {};
    records.forEach(r => {
      const key = `${r.studentName.toLowerCase()}|${r.infractionType}|${r.date}`;
      if (!map[key]) map[key] = new Set();
      map[key].add(r.enteredBy);
    });
    return map;
  }, [records]);

  // Identify currently restricted students
  const activeRestrictedNames = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    return new Set(restrictions.filter(r => r.endDate >= today).map(r => r.studentName));
  }, [restrictions]);

  useEffect(() => {
    if (records.length > prevRecordsLength.current) {
      setCurrentPage(1);
    }
    prevRecordsLength.current = records.length;
  }, [records]);

  const indexOfLastRecord = currentPage * ITEMS_PER_PAGE;
  const indexOfFirstRecord = indexOfLastRecord - ITEMS_PER_PAGE;
  const currentRecords = records.slice(indexOfFirstRecord, indexOfLastRecord);
  const totalPages = Math.ceil(records.length / ITEMS_PER_PAGE);

  const handleExportToExcel = () => {
    if (reportRecords.length === 0) return;
    
    const dataToExport = reportRecords.map(rec => {
      const key = `${rec.studentName.toLowerCase()}|${rec.infractionType}|${rec.date}`;
      const allReporters = Array.from(consensusMap[key] || []);
      const coReporters = allReporters.filter(email => email !== rec.enteredBy);
      
      return {
        "Incident Date": rec.date,
        "Student Identity": rec.studentName,
        "Grade Level": rec.grade,
        "Violation Category": rec.infractionType,
        "Logged By (Primary)": rec.enteredBy,
        "Multiple Staff Confirmation": allReporters.length > 1 ? "COLLABORATIVE REPORT" : "SINGLE OBSERVATION",
        "Team Reporters (Email IDs)": allReporters.join('; '),
        "Incident Detail Notes": rec.notes,
        "Active Restriction Status": activeRestrictedNames.has(rec.studentName) ? "NO PLAY PERIOD" : "Active"
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    
    // Auto-size columns for better readability
    const maxWidths = dataToExport.reduce((acc, row) => {
      Object.keys(row).forEach((key, i) => {
        const val = row[key as keyof typeof row] || "";
        acc[i] = Math.max(acc[i] || 0, key.length, val.toString().length);
      });
      return acc;
    }, [] as number[]);
    worksheet['!cols'] = maxWidths.map(w => ({ w: w + 2 }));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, `Discipline Audit`);
    XLSX.writeFile(workbook, `School_Discipline_Audit_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleViewReport = () => {
    let filtered: DisciplineRecord[] = [];

    if (reportDuration === 'custom') {
      if (!customStartDate || !customEndDate) {
        alert("Please select both start and end dates for the custom report.");
        return;
      }
      filtered = records.filter(r => {
        const d = r.date;
        return d >= customStartDate && d <= customEndDate;
      });
    } else {
      const days = reportDuration === 'weekly' ? 7 : 30;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      const startStr = startDate.toISOString().split('T')[0];
      filtered = records.filter(r => r.date >= startStr);
    }

    if (filtered.length === 0) { 
      alert("No records found for the selected period."); 
      return; 
    }
    setReportRecords(filtered);
    setIsModalOpen(true);
  };

  return (
    <>
      {isModalOpen && (
        <ReportModal 
          records={reportRecords}
          reportType={reportDuration}
          onClose={() => setIsModalOpen(false)}
          onExport={handleExportToExcel}
          consensusMap={consensusMap}
        />
      )}
      <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-100">
          <div className="flex flex-col mb-8 gap-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-slate-800 uppercase tracking-widest">Live Activity Log</h2>
                <div className="flex items-center gap-2">
                  <span className="flex h-2 w-2 rounded-full bg-indigo-500 animate-pulse"></span>
                  <span className="text-[10px] font-black text-slate-400 uppercase">Syncing with Staff</span>
                </div>
              </div>
              
              <div className="flex flex-col space-y-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Reporting & Data Extraction</p>
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <select
                    value={reportDuration}
                    onChange={(e) => setReportDuration(e.target.value as any)}
                    className="block w-full sm:w-auto px-4 py-2 text-sm border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                  >
                    <option value="weekly">This Week</option>
                    <option value="monthly">This Month</option>
                    <option value="custom">Date Range Selection</option>
                  </select>

                  {reportDuration === 'custom' && (
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <input 
                        type="date" 
                        value={customStartDate}
                        onChange={(e) => setCustomStartDate(e.target.value)}
                        className="px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
                      />
                      <span className="text-slate-400 text-xs font-bold">to</span>
                      <input 
                        type="date" 
                        value={customEndDate}
                        onChange={(e) => setCustomEndDate(e.target.value)}
                        className="px-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  )}

                  <button
                    onClick={handleViewReport}
                    className="w-full sm:w-auto bg-indigo-600 text-white px-6 py-2.5 rounded-lg font-black text-[10px] uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-md active:scale-95"
                  >
                    Generate & Audit
                  </button>
                </div>
              </div>
          </div>
          
          {records.length === 0 ? (
              <div className="text-center py-20 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                  <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">Awaiting records from staff...</p>
              </div>
          ) : (
            <>
              <div className="space-y-6">
                  {currentRecords.map((record) => {
                      const key = `${record.studentName.toLowerCase()}|${record.infractionType}|${record.date}`;
                      const allReporters = Array.from(consensusMap[key] || []);
                      const coReporters = allReporters.filter(email => email !== record.enteredBy);
                      
                      return (
                        <div key={record.id} className="relative">
                           {violators[record.studentName] >= 3 && (
                              <div className="absolute -top-3 left-4 z-10 bg-amber-500 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-full shadow-sm">
                                Frequent Violator
                              </div>
                           )}
                           <RecordCard 
                            record={record} 
                            coReporters={coReporters.length > 0 ? coReporters : undefined} 
                           />
                        </div>
                      );
                  })}
              </div>
              {totalPages > 1 && (
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={setCurrentPage}
                />
              )}
            </>
          )}
      </div>
    </>
  );
};

export default RecordList;
