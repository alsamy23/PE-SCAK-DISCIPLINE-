
import React, { useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';

interface QRScannerProps {
  onScanSuccess: (decodedText: string) => void;
  onClose: () => void;
}

const QRScanner: React.FC<QRScannerProps> = ({ onScanSuccess, onClose }) => {
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  useEffect(() => {
    // Only initialize when the component is rendered (which happens only after clicking 'QR SCAN')
    const initScanner = async () => {
      try {
        if (!scannerRef.current) {
          const scanner = new Html5QrcodeScanner(
            'qr-reader', 
            { 
              fps: 10, 
              qrbox: { width: 250, height: 250 },
              rememberLastUsedCamera: true,
              // Supported formats: QR_CODE
            },
            /* verbose= */ false
          );

          const handleSuccess = (decodedText: string) => {
            onScanSuccess(decodedText);
          };

          const handleError = (error: string) => {
            // This callback is called frequently, so we don't alert here.
          };

          scanner.render(handleSuccess, handleError);
          scannerRef.current = scanner;
        }
      } catch (err) {
        console.error("Camera access failed or scanner init error:", err);
      }
    };

    initScanner();

    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear().catch(error => {
          console.error("Failed to clear html5-qrcode-scanner.", error);
        });
        scannerRef.current = null;
      }
    };
  }, [onScanSuccess]);

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex flex-col items-center justify-center z-[100] animate-slide-in-fade">
      <div className="bg-white rounded-[2rem] shadow-2xl p-6 md:p-10 w-full max-w-md mx-4 border border-slate-200">
        <h2 className="text-xl font-black text-center text-slate-800 mb-6 uppercase tracking-tight">Align Student QR Code</h2>
        <div id="qr-reader" className="w-full rounded-2xl overflow-hidden border border-slate-100 bg-slate-50"></div>
        <p className="mt-4 text-[10px] text-center text-slate-400 font-black uppercase tracking-widest">Scanning active...</p>
        <button
          onClick={onClose}
          className="mt-8 w-full flex justify-center py-4 px-4 border border-slate-200 rounded-xl shadow-sm text-xs font-black uppercase tracking-widest text-slate-600 bg-slate-50 hover:bg-slate-100 transition-all active:scale-95"
        >
          Close Scanner
        </button>
      </div>
    </div>
  );
};

export default QRScanner;
