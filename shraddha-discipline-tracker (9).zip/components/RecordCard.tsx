
import React, { useState, useCallback } from 'react';
import { DisciplineRecord, InfractionType } from '../types';
import generateDisciplineNote from '../services/geminiService';

interface RecordCardProps {
  record: DisciplineRecord;
  coReporters?: string[];
}

const InfractionIcon: React.FC<{ type: InfractionType }> = ({ type }) => {
    const iconColor = "text-slate-500";
    const iconSize = "h-6 w-6";
    switch(type) {
        case InfractionType.HAIR_CUT:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M14.121 14.121L15 15m2.879-2.879l-1.414-1.414m0 0L10.5 3.5v7m-1.414 4.5l-4.243 4.243-1.414-1.414 4.243-4.243m-2.829-2.829l-4.243-4.243 1.414-1.414 4.243 4.243" /></svg>;
        case InfractionType.UNIFORM:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 11V7a4 4 0 118 0v4M5 9h14l1 12H4L5 9z" /></svg>;
        case InfractionType.LATE_COMER:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
        case InfractionType.ID_CARD:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0z" /></svg>;
        default:
            return <svg xmlns="http://www.w3.org/2000/svg" className={`${iconSize} ${iconColor}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" /></svg>;
    }
};

const LoadingSpinner: React.FC = () => (
    <div className="flex items-center space-x-2">
        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-slate-500"></div>
        <span className="text-sm text-slate-500">Generating...</span>
    </div>
);

const RecordCard: React.FC<RecordCardProps> = ({ record, coReporters }) => {
  const [generatedNote, setGeneratedNote] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleGenerateNote = useCallback(async () => {
    setIsLoading(true);
    setGeneratedNote('');
    const note = await generateDisciplineNote(record);
    setGeneratedNote(note);
    setIsLoading(false);
  }, [record]);

  return (
    <div className={`border border-slate-200 rounded-xl p-6 transition-all hover:shadow-xl hover:border-indigo-100 bg-white ${record.isNew ? 'animate-slide-in-fade' : ''} ${coReporters ? 'border-l-4 border-l-indigo-500' : ''}`}>
      <div className="flex flex-col sm:flex-row justify-between sm:items-start gap-4">
        <div className="flex-1">
          <div className="flex items-center flex-wrap gap-2 mb-1">
            <h3 className="text-lg font-black text-slate-800">{record.studentName}</h3>
            {coReporters && (
               <div className="bg-indigo-600 text-white text-[8px] font-black uppercase px-2 py-0.5 rounded flex items-center shadow-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-2 w-2 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                  Multiple Reports
               </div>
            )}
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Grade {record.grade} • Recorded {record.date}</p>
          
          {coReporters && (
            <div className="mt-3 flex items-center gap-2">
              <span className="text-[9px] font-black text-indigo-500 uppercase tracking-tight">Verified by colleagues:</span>
              <div className="flex -space-x-1">
                 {coReporters.map((email, i) => (
                    <div key={i} className="h-5 w-5 flex items-center justify-center bg-indigo-50 border border-indigo-200 text-[8px] font-black text-indigo-600 rounded-full shadow-sm" title={email}>
                      {email.charAt(0).toUpperCase()}
                    </div>
                 ))}
              </div>
            </div>
          )}
        </div>
        <div className="flex items-center space-x-3 bg-slate-50 px-4 py-2 rounded-2xl border border-slate-100 self-start">
            <InfractionIcon type={record.infractionType} />
            <span className="text-xs font-black text-slate-700 uppercase tracking-tight">{record.infractionType}</span>
        </div>
      </div>
      
      <div className="mt-4 p-4 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
         <p className="text-slate-600 text-sm leading-relaxed">{record.notes || "Standard violation logged."}</p>
      </div>
      
      <div className="mt-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <button
          onClick={handleGenerateNote}
          disabled={isLoading}
          className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black uppercase tracking-widest rounded-lg shadow-md disabled:bg-slate-200 disabled:cursor-not-allowed transition-all active:scale-95"
        >
          {isLoading ? 'Consulting AI...' : 'Create Formal Parent Note'}
        </button>
        <div className="text-right">
           <p className="text-[10px] text-slate-500 font-black uppercase">Staff: {record.enteredBy.split('@')[0]}</p>
        </div>
      </div>

      {isLoading && <div className="mt-4"><LoadingSpinner /></div>}
      
      {generatedNote && (
        <div className="mt-4 p-5 bg-indigo-50 rounded-2xl border border-indigo-100 shadow-inner animate-slide-in-fade">
            <h4 className="font-black text-[10px] uppercase text-indigo-400 mb-2 tracking-widest flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              AI-Generated Parent Communication:
            </h4>
            <p className="text-sm text-slate-700 whitespace-pre-wrap italic font-medium leading-relaxed">"{generatedNote}"</p>
            <button 
              onClick={() => { navigator.clipboard.writeText(generatedNote); alert('Copied to clipboard!'); }}
              className="mt-4 px-3 py-1 bg-white border border-indigo-100 text-[9px] font-black uppercase text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg transition-all"
            >
              Copy Text
            </button>
        </div>
      )}
    </div>
  );
};

export default RecordCard;
