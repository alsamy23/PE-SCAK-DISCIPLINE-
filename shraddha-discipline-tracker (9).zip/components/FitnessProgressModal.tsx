
import React from 'react';
import { FitnessRecord } from '../types';
import { 
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, 
  ResponsiveContainer, Legend, Tooltip
} from 'recharts';

interface FitnessProgressModalProps {
  record: FitnessRecord;
  onClose: () => void;
}

const FitnessProgressModal: React.FC<FitnessProgressModalProps> = ({ record, onClose }) => {
  const chartData = [
    { subject: '50m Speed', baseline: record.baseline.speed50m, final: record.final?.speed50m ?? 0, fullMark: 10 },
    { subject: '600m Endur', baseline: record.baseline.endurance600m, final: record.final?.endurance600m ?? 0, fullMark: 10 },
    { subject: 'Strength', baseline: record.baseline.strength, final: record.final?.strength ?? 0, fullMark: 10 },
    { subject: 'Flexibility', baseline: record.baseline.flexibility, final: record.final?.flexibility ?? 0, fullMark: 10 },
    { subject: 'Curls Up', baseline: record.baseline.curlsUp, final: record.final?.curlsUp ?? 0, fullMark: 10 },
    { subject: 'Skill 1', baseline: record.baseline.gameSkill1, final: record.final?.gameSkill1 ?? 0, fullMark: 20 },
    { subject: 'Skill 2', baseline: record.baseline.gameSkill2, final: record.final?.gameSkill2 ?? 0, fullMark: 20 },
    { subject: 'Discipline', baseline: record.baseline.discipline, final: record.final?.discipline ?? 0, fullMark: 10 },
  ];

  const improvement = record.final ? (record.final.total - record.baseline.total) : 0;

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md flex items-center justify-center z-[60] p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-5xl max-h-[95vh] overflow-y-auto animate-slide-in-fade border border-slate-200">
        <div className="sticky top-0 z-10 px-8 py-6 border-b flex justify-between items-center bg-white/80 backdrop-blur-sm">
          <div>
            <h2 className="text-3xl font-black text-slate-800 uppercase tracking-tight">{record.name}</h2>
            <p className="text-xs font-black text-indigo-500 uppercase tracking-widest mt-1">
              {record.class} • {record.section} | Roll No {record.rollNo}
            </p>
          </div>
          <button onClick={onClose} className="p-3 bg-slate-50 border border-slate-200 hover:bg-rose-50 hover:text-rose-600 rounded-full transition-all">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-10">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
            {/* Charts Section */}
            <div className="lg:col-span-3 h-[500px] bg-slate-50 p-8 rounded-3xl border border-slate-200">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center">
                <span className="w-2 h-2 bg-indigo-500 rounded-full mr-2"></span>
                Performance Analysis (100pt Scale)
              </h3>
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                  <PolarGrid stroke="#e2e8f0" />
                  <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fontWeight: 900, fill: '#64748b' }} />
                  <PolarRadiusAxis angle={30} domain={[0, 20]} tick={{ fontSize: 8 }} />
                  <Radar name="Baseline" dataKey="baseline" stroke="#6366f1" strokeWidth={3} fill="#6366f1" fillOpacity={0.2} />
                  {record.final && <Radar name="Final" dataKey="final" stroke="#10b981" strokeWidth={3} fill="#10b981" fillOpacity={0.3} />}
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase' }} />
                  <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                </RadarChart>
              </ResponsiveContainer>
            </div>

            {/* Metrics Section */}
            <div className="lg:col-span-2 space-y-8">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 text-center">
                   <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Baseline Score</p>
                   <p className="text-4xl font-black text-indigo-700">{record.baseline.total}</p>
                   <span className="text-xs font-black text-indigo-400">GRADE {record.baseline.grade}</span>
                </div>
                <div className={`p-6 rounded-2xl border text-center ${record.final ? 'bg-emerald-50 border-emerald-100' : 'bg-slate-50 border-slate-200 opacity-50'}`}>
                   <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">Final Score</p>
                   <p className="text-4xl font-black text-emerald-700">{record.final?.total || '---'}</p>
                   <span className="text-xs font-black text-emerald-400">GRADE {record.final?.grade || '-'}</span>
                </div>
              </div>

              {record.final && (
                <div className={`p-6 rounded-2xl border flex items-center justify-between ${improvement >= 0 ? 'bg-emerald-600' : 'bg-rose-600'} text-white shadow-xl`}>
                  <div>
                    <p className="text-[10px] font-black uppercase opacity-80 tracking-widest">Net Progress</p>
                    <p className="text-3xl font-black">{improvement > 0 ? `+${improvement}` : improvement} pts</p>
                  </div>
                </div>
              )}

              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Health Profile</h4>
                <div className="flex gap-4">
                   <div className="flex-1">
                      <span className="block text-[8px] font-bold text-slate-400 uppercase">HT (cm)</span>
                      <span className="text-sm font-black text-slate-700">{record.final?.height || record.baseline.height}</span>
                   </div>
                   <div className="flex-1">
                      <span className="block text-[8px] font-bold text-slate-400 uppercase">WT (kg)</span>
                      <span className="text-sm font-black text-slate-700">{record.final?.weight || record.baseline.weight}</span>
                   </div>
                   <div className="flex-1">
                      <span className="block text-[8px] font-bold text-slate-400 uppercase">BMI</span>
                      <span className="text-sm font-black text-indigo-600">{record.final?.bmi || record.baseline.bmi}</span>
                   </div>
                </div>
              </div>

              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Coach Observations</h4>
                <p className="text-slate-600 text-sm italic leading-relaxed">
                  {record.final?.remark || record.baseline.remark || "Continuous physical development noted."}
                </p>
              </div>

              <button onClick={() => window.print()} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-lg hover:bg-black transition-all">Print Fitness Certificate</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FitnessProgressModal;
