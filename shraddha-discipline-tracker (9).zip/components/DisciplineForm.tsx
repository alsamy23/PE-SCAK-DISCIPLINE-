
import React, { useState, useRef, useEffect } from 'react';
import { DisciplineRecord, InfractionType, Student } from '../types';
import QRScanner from './QRScanner';

interface DisciplineFormProps {
  onAddRecord: (record: Omit<DisciplineRecord, 'id' | 'date' | 'enteredBy'>) => void;
  students: Student[];
}

const DisciplineForm: React.FC<DisciplineFormProps> = ({ onAddRecord, students }) => {
  const [studentName, setStudentName] = useState('');
  const [selectedClass, setSelectedClass] = useState('1');
  const [selectedSection, setSelectedSection] = useState('A');
  const [infractionType, setInfractionType] = useState<InfractionType>(InfractionType.UNIFORM);
  const [notes, setNotes] = useState('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [searchResults, setSearchResults] = useState<Student[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [scanSuccessMsg, setScanSuccessMsg] = useState<{ text: string, type: 'success' | 'warning' } | null>(null);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const classes = [
    'Play Group', 'Pre KG', 'LKG', 'UKG',
    '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'
  ];
  const sections_1_to_10 = ['A', 'B', 'C', 'D'];
  const sections_11_to_12 = ['A1', 'A2', 'B', 'C'];
  
  const getAvailableSections = (className: string) => {
    const classNum = parseInt(className, 10);
    if (!isNaN(classNum) && classNum >= 11) {
      return sections_11_to_12;
    }
    return sections_1_to_10;
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleClassChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newClass = e.target.value;
    setSelectedClass(newClass);
    const sections = getAvailableSections(newClass);
    if (!sections.includes(selectedSection)) {
      setSelectedSection(sections[0]);
    }
  };
  
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setStudentName(query);
    setScanSuccessMsg(null);

    if (query.length > 0) {
      const q = query.toLowerCase().trim();
      const filteredStudents = students.filter(student =>
        student.name.toLowerCase().includes(q) ||
        (student.enrollmentNo && student.enrollmentNo.toLowerCase().includes(q))
      ).slice(0, 10);
      setSearchResults(filteredStudents);
      setShowResults(true);
    } else {
      setSearchResults([]);
      setShowResults(false);
    }
  };
  
  const handleStudentSelect = (student: Student) => {
    setStudentName(student.name);
    setSelectedClass(student.class);
    setSelectedSection(student.section);
    setShowResults(false);
    setSearchResults([]);
    setScanSuccessMsg({ text: `Auto-filled: ${student.name}`, type: 'success' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim()) {
      alert('Please enter or scan student name.');
      return;
    }
    const grade = `${selectedClass} ${selectedSection}`;
    onAddRecord({ studentName, grade, infractionType, notes });
    setStudentName('');
    setNotes('');
    setShowResults(false);
    setScanSuccessMsg(null);
  };
  
  const handleScanSuccess = (decodedText: string) => {
    let scannedId = decodedText.trim();
    
    // Robust detection: QR might be a link, extract the ID
    try {
      if (scannedId.toLowerCase().includes('http')) {
        const url = new URL(scannedId);
        scannedId = url.searchParams.get('id') || url.pathname.split('/').pop() || scannedId;
      }
    } catch (e) {}

    const normalizedId = scannedId.toLowerCase();
    const matchedStudent = students.find(s => 
      s.enrollmentNo?.toLowerCase() === normalizedId || 
      s.id.toLowerCase() === normalizedId
    );

    if (matchedStudent) {
      setStudentName(matchedStudent.name);
      setSelectedClass(matchedStudent.class);
      setSelectedSection(matchedStudent.section);
      setScanSuccessMsg({ 
        text: `Detected: ${matchedStudent.name} (ID: ${scannedId})`, 
        type: 'success' 
      });
    } else {
      setStudentName(scannedId);
      setScanSuccessMsg({ 
        text: `ID "${scannedId}" not found. Using as raw text.`, 
        type: 'warning' 
      });
    }
    
    setIsScannerOpen(false);
  };
  
  const availableSections = getAvailableSections(selectedClass);

  return (
    <>
      {isScannerOpen && (
          <QRScanner 
              onScanSuccess={handleScanSuccess} 
              onClose={() => setIsScannerOpen(false)} 
          />
      )}
      <div className="bg-white p-6 rounded-2xl shadow-xl h-full border border-slate-100 animate-slide-in-fade">
        <h2 className="text-xl font-black text-slate-800 mb-6 flex items-center uppercase tracking-widest">
           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
            Record Violation
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative" ref={searchContainerRef}>
            <div className="flex justify-between items-center mb-1">
              <label htmlFor="studentName" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">
                Student Name or ID
              </label>
              <button 
                type="button" 
                onClick={() => setIsScannerOpen(true)}
                className="inline-flex items-center text-[10px] font-black text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-2 py-1 rounded border border-indigo-100 transition-all active:scale-95"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v1m6 11h2m-6.5 6.5v-1m-6.5-5.5H4M4 12l1.5-1.5M4 4l1.5 1.5M12 20v-1m6-11h-2M17.5 4.5l-1.5 1.5M20 20l-1.5-1.5" />
                </svg>
                QR SCAN
              </button>
            </div>
            <input
              id="studentName"
              type="text"
              value={studentName}
              onChange={handleNameChange}
              autoComplete="off"
              className={`block w-full px-4 py-3 bg-slate-50 border rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all ${scanSuccessMsg ? (scanSuccessMsg.type === 'success' ? 'border-emerald-500 bg-emerald-50' : 'border-amber-500 bg-amber-50') : 'border-slate-200'}`}
              placeholder="e.g. SCAK002226 or Senora L"
              required
            />
            {scanSuccessMsg && (
              <p className={`mt-2 text-[10px] font-black uppercase tracking-tight flex items-center ${scanSuccessMsg.type === 'success' ? 'text-emerald-600' : 'text-amber-600'}`}>
                {scanSuccessMsg.type === 'success' ? (
                  <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                ) : (
                  <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>
                )}
                {scanSuccessMsg.text}
              </p>
            )}
            {showResults && searchResults.length > 0 && (
              <ul className="absolute z-50 w-full bg-white border border-slate-200 rounded-xl mt-2 shadow-2xl max-h-60 overflow-y-auto animate-slide-in-fade border-b-4 border-indigo-600">
                {searchResults.map((student, index) => (
                  <li
                    key={`${student.id}-${index}`}
                    className="px-4 py-3 hover:bg-indigo-50 cursor-pointer border-b border-slate-50 last:border-0 transition-colors"
                    onClick={() => handleStudentSelect(student)}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-bold text-sm text-slate-800">{student.name}</p>
                        <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">Grade {student.class} • {student.section}</p>
                      </div>
                      {student.enrollmentNo && (
                        <div className="text-right">
                          <p className="text-[9px] font-mono font-black text-indigo-400 bg-indigo-50 px-2 py-1 rounded">ID: {student.enrollmentNo}</p>
                        </div>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="class" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                  Grade / Class
                </label>
                <select
                  id="class"
                  value={selectedClass}
                  onChange={handleClassChange}
                  className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                >
                  {classes.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                  {!classes.includes(selectedClass) && (
                    <option key={selectedClass} value={selectedClass}>{selectedClass}</option>
                  )}
                </select>
              </div>
              <div>
                <label htmlFor="section" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                  Section
                </label>
                <select
                  id="section"
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                >
                  {availableSections.map((section) => (
                    <option key={section} value={section}>{section}</option>
                  ))}
                  {!availableSections.includes(selectedSection) && (
                    <option key={selectedSection} value={selectedSection}>{selectedSection}</option>
                  )}
                </select>
              </div>
          </div>
          
          <div>
            <label htmlFor="infractionType" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
              Violation Type
            </label>
            <select
              id="infractionType"
              value={infractionType}
              onChange={(e) => setInfractionType(e.target.value as InfractionType)}
              className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            >
              {Object.values(InfractionType).map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="notes" className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
              Incident Notes
            </label>
            <textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              placeholder="Provide specific details about the issue..."
            />
          </div>
          <button
            type="submit"
            className="w-full flex justify-center py-4 px-4 border border-transparent rounded-xl shadow-lg text-xs font-black text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none transition-all active:scale-[0.98] uppercase tracking-widest"
          >
            Log Violation
          </button>
        </form>
      </div>
    </>
  );
};

export default DisciplineForm;
