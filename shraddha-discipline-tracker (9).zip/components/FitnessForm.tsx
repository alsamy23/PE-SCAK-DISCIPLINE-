
import React, { useState, useEffect, useRef } from 'react';
import { FitnessRecord, FitnessMetrics, Student } from '../types';

interface FitnessFormProps {
  onAddRecord: (record: FitnessRecord) => void;
  onClose: () => void;
  students: Student[];
}

const FitnessForm: React.FC<FitnessFormProps> = ({ onAddRecord, onClose, students }) => {
  const [formData, setFormData] = useState({
    rollNo: '',
    name: '',
    class: 'III',
    section: 'A',
    testType: 'baseline' as 'baseline' | 'final',
    height: '',
    weight: '',
    speed50m: '',
    endurance600m: '',
    strength: '',
    flexibility: '',
    curlsUp: '',
    gameSkill1: '',
    gameSkill2: '',
    discipline: '',
    remark: ''
  });

  const [bmi, setBmi] = useState<number>(0);
  const [total, setTotal] = useState<number>(0);
  const [grade, setGrade] = useState<string>('E');
  const [searchResults, setSearchResults] = useState<Student[]>([]);
  const [showResults, setShowResults] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Auto-calculate BMI
  useEffect(() => {
    const h = parseFloat(formData.height) / 100;
    const w = parseFloat(formData.weight);
    setBmi(h > 0 && w > 0 ? w / (h * h) : 0);
  }, [formData.height, formData.weight]);

  // Auto-calculate Total and Grade
  useEffect(() => {
    const sum = 
      (parseFloat(formData.speed50m) || 0) +
      (parseFloat(formData.endurance600m) || 0) +
      (parseFloat(formData.strength) || 0) +
      (parseFloat(formData.flexibility) || 0) +
      (parseFloat(formData.curlsUp) || 0) +
      (parseFloat(formData.gameSkill1) || 0) +
      (parseFloat(formData.gameSkill2) || 0) +
      (parseFloat(formData.discipline) || 0);
    
    setTotal(sum);
    if (sum >= 90) setGrade('A');
    else if (sum >= 75) setGrade('B');
    else if (sum >= 60) setGrade('C');
    else if (sum >= 45) setGrade('D');
    else setGrade('E');
  }, [formData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if (name === 'name') {
      if (value.length > 1) {
        const filtered = students.filter(s => s.name.toLowerCase().includes(value.toLowerCase())).slice(0, 10);
        setSearchResults(filtered);
        setShowResults(true);
      } else {
        setShowResults(false);
      }
    }
  };

  const handleStudentSelect = (student: Student) => {
    setFormData(prev => ({
      ...prev,
      name: student.name,
      class: student.class,
      section: student.section
    }));
    setShowResults(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const metrics: FitnessMetrics = {
      height: parseFloat(formData.height) || 0,
      weight: parseFloat(formData.weight) || 0,
      bmi: parseFloat(bmi.toFixed(2)),
      speed50m: parseFloat(formData.speed50m) || 0,
      endurance600m: parseFloat(formData.endurance600m) || 0,
      strength: parseFloat(formData.strength) || 0,
      flexibility: parseFloat(formData.flexibility) || 0,
      curlsUp: parseFloat(formData.curlsUp) || 0,
      gameSkill1: parseFloat(formData.gameSkill1) || 0,
      gameSkill2: parseFloat(formData.gameSkill2) || 0,
      discipline: parseFloat(formData.discipline) || 0,
      total: total,
      grade: grade,
      remark: formData.remark
    };

    const newRecord: FitnessRecord = {
      rollNo: parseInt(formData.rollNo) || 0,
      name: formData.name,
      class: formData.class,
      section: formData.section,
      baseline: formData.testType === 'baseline' ? metrics : metrics,
      final: formData.testType === 'final' ? metrics : undefined
    };

    onAddRecord(newRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[70] p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b flex justify-between items-center bg-indigo-600 text-white rounded-t-xl">
          <h2 className="text-xl font-bold">Record Fitness Metrics (100 pts)</h2>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded-full transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="md:col-span-2 flex bg-slate-100 p-1 rounded-lg">
            <button 
              type="button"
              onClick={() => setFormData(p => ({...p, testType: 'baseline'}))}
              className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${formData.testType === 'baseline' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
            >
              Baseline Test
            </button>
            <button 
              type="button"
              onClick={() => setFormData(p => ({...p, testType: 'final'}))}
              className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${formData.testType === 'final' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500'}`}
            >
              Final Test
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative" ref={searchContainerRef}>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Student Name</label>
              <input 
                name="name" 
                value={formData.name} 
                onChange={handleChange} 
                autoComplete="off"
                className="w-full px-3 py-2 border-slate-200 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" 
                placeholder="Search master list..."
                required 
              />
              {showResults && searchResults.length > 0 && (
                <ul className="absolute z-50 w-full bg-white border border-slate-200 rounded-md mt-1 shadow-2xl max-h-60 overflow-y-auto">
                  {searchResults.map((s, i) => (
                    <li key={i} className="px-4 py-3 hover:bg-slate-50 cursor-pointer border-b last:border-0" onClick={() => handleStudentSelect(s)}>
                      <p className="font-bold text-sm text-slate-800">{s.name}</p>
                      <p className="text-[10px] text-slate-500 uppercase font-black">{s.class} - {s.section}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Roll No</label>
              <input type="number" name="rollNo" value={formData.rollNo} onChange={handleChange} className="w-full px-3 py-2 border-slate-200 border rounded-lg" required />
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
            <h3 className="text-sm font-black text-slate-400 uppercase mb-4 border-b pb-2">Measurements</h3>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">HT (cm)</label>
                <input type="number" name="height" value={formData.height} onChange={handleChange} className="w-full px-3 py-2 border border-slate-200 rounded-md" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">WT (kg)</label>
                <input type="number" name="weight" value={formData.weight} onChange={handleChange} className="w-full px-3 py-2 border border-slate-200 rounded-md" />
              </div>
              <div className="bg-white p-2 border border-slate-200 rounded-md text-center">
                <span className="text-[8px] text-slate-400 block uppercase font-black">BMI</span>
                <span className="text-xs font-black text-indigo-600">{bmi.toFixed(1)}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
            <h3 className="text-sm font-black text-slate-400 uppercase mb-4 border-b pb-2">Physical Tests (Points)</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">50m Speed (10)</label>
                <input type="number" step="0.5" max="10" name="speed50m" value={formData.speed50m} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">600m Endur (10)</label>
                <input type="number" step="0.5" max="10" name="endurance600m" value={formData.endurance600m} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">Strength (10)</label>
                <input type="number" step="0.5" max="10" name="strength" value={formData.strength} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">Flexibility (10)</label>
                <input type="number" step="0.5" max="10" name="flexibility" value={formData.flexibility} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">Curls Up (10)</label>
                <input type="number" step="0.5" max="10" name="curlsUp" value={formData.curlsUp} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">Skill 1 (20)</label>
                <input type="number" step="0.5" max="20" name="gameSkill1" value={formData.gameSkill1} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">Skill 2 (20)</label>
                <input type="number" step="0.5" max="20" name="gameSkill2" value={formData.gameSkill2} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 mb-1">Discipline (10)</label>
                <input type="number" step="0.5" max="10" name="discipline" value={formData.discipline} onChange={handleChange} className="w-full px-2 py-1.5 border border-slate-200 rounded" />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-slate-900 rounded-lg text-white">
            <div className="flex items-center gap-6">
              <div>
                <span className="text-[10px] uppercase text-slate-400 block font-bold">Total Score</span>
                <span className="text-2xl font-black text-indigo-400">{total}/100</span>
              </div>
              <div>
                <span className="text-[10px] uppercase text-slate-400 block font-bold">Grade</span>
                <span className="text-2xl font-black text-emerald-400">{grade}</span>
              </div>
            </div>
            <button type="submit" className="px-8 py-3 bg-indigo-500 hover:bg-indigo-400 text-white rounded-md font-bold transition-all shadow-lg active:scale-95">
              Save Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FitnessForm;
