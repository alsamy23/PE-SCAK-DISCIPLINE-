
import React, { useState, useMemo } from 'react';
import { FitnessRecord, Student, FitnessMetrics } from '../types';
import FitnessProgressModal from './FitnessProgressModal';
import FitnessAnalysisModal from './FitnessAnalysisModal';
import FitnessForm from './FitnessForm';
import { saveFitnessRecord } from '../services/firebase';
import * as XLSX from 'xlsx';

interface FitnessTrackerProps {
  students: Student[];
  records: FitnessRecord[];
  onUpdateRecords: (records: FitnessRecord[]) => void;
}

const FitnessTracker: React.FC<FitnessTrackerProps> = ({ students, records, onUpdateRecords }) => {
  const [selectedRecord, setSelectedRecord] = useState<FitnessRecord | null>(null);
  const [analysisModal, setAnalysisModal] = useState<{ open: boolean; title: string }>({ open: false, title: '' });
  const [viewMode, setViewMode] = useState<'baseline' | 'final'>('baseline');
  const [filterClass, setFilterClass] = useState('All');
  const [filterSection, setFilterSection] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [showImportDropdown, setShowImportDropdown] = useState(false);

  // Status stats
  const stats = useMemo(() => {
    const totalStudents = students.length || records.length;
    const withBaseline = records.length;
    const withFinal = records.filter(r => r.final).length;
    return {
      total: totalStudents,
      baseline: withBaseline,
      final: withFinal,
      completionRate: totalStudents > 0 ? Math.round((withBaseline / totalStudents) * 100) : 0
    };
  }, [records, students]);

  const availableClasses = useMemo(() => {
    const classes = new Set([...records.map(r => r.class), ...students.map(s => s.class)]);
    return ['All', ...Array.from(classes).sort()];
  }, [records, students]);

  const availableSections = useMemo(() => {
    const relevantSource = filterClass === 'All' ? [...records, ...students] : [...records, ...students].filter(r => r.class === filterClass);
    const sections = new Set(relevantSource.map(r => r.section));
    return ['All', ...Array.from(sections).sort()];
  }, [records, students, filterClass]);

  const filteredRecords = useMemo(() => {
    const q = searchTerm.toLowerCase().trim();
    const terms = q.split(/\s+/);
    
    return records.filter(r => {
      const matchClass = filterClass === 'All' || r.class === filterClass;
      const matchSection = filterSection === 'All' || r.section === filterSection;
      
      let matchSearch = true;
      if (q) {
        const name = r.name.toLowerCase();
        const roll = r.rollNo.toString();
        matchSearch = roll.includes(q) || terms.every(term => name.includes(term));
      }
      
      return matchClass && matchSection && matchSearch;
    });
  }, [records, filterClass, filterSection, searchTerm]);

  const handleAddFitnessRecord = async (newRecord: FitnessRecord) => {
    await saveFitnessRecord(newRecord);
    const existingIdx = records.findIndex(r => r.name === newRecord.name && r.class === newRecord.class && r.section === newRecord.section);
    let updated: FitnessRecord[];
    if (existingIdx >= 0) {
      updated = [...records];
      if (newRecord.final) {
        updated[existingIdx] = { ...updated[existingIdx], final: newRecord.final };
      } else {
        updated[existingIdx] = { ...updated[existingIdx], baseline: newRecord.baseline };
      }
    } else {
      updated = [newRecord, ...records];
    }
    onUpdateRecords(updated);
  };

  const handleImportFitness = (e: React.ChangeEvent<HTMLInputElement>, target: 'baseline' | 'final') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    setShowImportDropdown(false);
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[];

        let updatedRecords = [...records];

        for (const row of jsonData) {
          const normalizedRow: any = {};
          Object.keys(row).forEach(k => {
            normalizedRow[k.trim().toLowerCase()] = row[k];
          });

          const name = (row['Name'] || row['Student Name'] || row['Name of the Student'] || normalizedRow['name'] || '').toString().trim();
          const className = (row['Class'] || row['Grade'] || normalizedRow['class'] || normalizedRow['grade'] || '').toString().trim();
          const section = (row['Section'] || normalizedRow['section'] || normalizedRow['sec'] || '').toString().trim();
          
          if (!name || !className) continue;

          const getNum = (aliases: string[]) => {
            for (const alias of aliases) {
              const val = normalizedRow[alias.toLowerCase()];
              if (val !== undefined && val !== null && val !== '') return parseFloat(val);
            }
            return 0;
          };

          const metrics: FitnessMetrics = {
            height: getNum(['height (cm)', 'ht', 'height', 'ht (cm)']),
            weight: getNum(['weight (kg)', 'wt', 'weight', 'wt (kg)']),
            bmi: getNum(['bmi']),
            speed50m: getNum(['50m speed test (10)', '50m speed test', '50m', 'speed', 'speed 50m']),
            endurance600m: getNum(['600m endurance (10)', '600m endurance', '600m', 'endurance', 'beep test']),
            strength: getNum(['strength (10)', 'strength', 'broad jump', 'standing broad jump']),
            flexibility: getNum(['flexibility (10)', 'flexibility', 'flex']),
            curlsUp: getNum(['curls up (10)', 'curls up', 'curls', 'abs']),
            gameSkill1: getNum(['game skill 1 (20)', 'game skill 1', 'skill 1']),
            gameSkill2: getNum(['game skill 2 (20)', 'game skill 2', 'skill 2']),
            discipline: getNum(['discipline (10)', 'discipline', 'disc']),
            total: 0,
            grade: 'E',
            remark: row['Remark'] || row['REMARK'] || normalizedRow['remark'] || ''
          };

          const h = metrics.height / 100;
          if (metrics.bmi === 0 && h > 0) {
            metrics.bmi = parseFloat((metrics.weight / (h * h)).toFixed(2));
          }

          metrics.total = metrics.speed50m + metrics.endurance600m + metrics.strength + 
                          metrics.flexibility + metrics.curlsUp + metrics.gameSkill1 + 
                          metrics.gameSkill2 + metrics.discipline;
          
          if (metrics.total >= 90) metrics.grade = 'A';
          else if (metrics.total >= 75) metrics.grade = 'B';
          else if (metrics.total >= 60) metrics.grade = 'C';
          else if (metrics.total >= 45) metrics.grade = 'D';

          const existingIdx = updatedRecords.findIndex(r => 
            r.name.toLowerCase() === name.toLowerCase() && 
            r.class.toLowerCase() === className.toLowerCase() && 
            r.section.toLowerCase() === section.toLowerCase()
          );
          
          if (existingIdx >= 0) {
            const currentRec = { ...updatedRecords[existingIdx] };
            if (target === 'baseline') {
              currentRec.baseline = metrics;
            } else {
              currentRec.final = metrics;
            }
            updatedRecords[existingIdx] = currentRec;
            await saveFitnessRecord(currentRec);
          } else {
            const rollNo = parseInt(row['Roll No'] || row['Roll'] || normalizedRow['roll no'] || normalizedRow['roll'] || 0);
            const rec: FitnessRecord = {
              rollNo,
              name, 
              class: className, 
              section,
              baseline: target === 'baseline' ? metrics : { ...metrics, total: 0, grade: 'E' },
              final: target === 'final' ? metrics : undefined
            };
            updatedRecords.push(rec);
            await saveFitnessRecord(rec);
          }
        }
        onUpdateRecords(updatedRecords);
        alert(`Success: Imported ${target} data for ${jsonData.length} students.`);
      } catch (err) {
        console.error("Import Error:", err);
        alert("Error importing Excel. Please check headers and data format.");
      } finally {
        setIsImporting(false);
        e.target.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const openAnalysis = (title: string) => {
    setAnalysisModal({ open: true, title });
  };

  return (
    <div className="space-y-6">
      {selectedRecord && (
        <FitnessProgressModal 
          record={selectedRecord} 
          onClose={() => setSelectedRecord(null)} 
        />
      )}

      {analysisModal.open && (
        <FitnessAnalysisModal 
          records={filteredRecords} 
          onClose={() => setAnalysisModal({ open: false, title: '' })}
          title={analysisModal.title}
        />
      )}

      {isFormOpen && (
        <FitnessForm 
          students={students}
          onAddRecord={handleAddFitnessRecord} 
          onClose={() => setIsFormOpen(false)} 
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl shadow-md border-b-4 border-indigo-500">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Master Roster</p>
          <p className="text-2xl font-black text-slate-800">{stats.total}</p>
        </div>
        <div className="bg-white p-4 rounded-xl shadow-md border-b-4 border-amber-500">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Baseline Done</p>
          <p className="text-2xl font-black text-slate-800">{stats.baseline}</p>
        </div>
        <div className="bg-white p-4 rounded-xl shadow-md border-b-4 border-emerald-500">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Final Tests</p>
          <p className="text-2xl font-black text-slate-800">{stats.final}</p>
        </div>
        <div className="bg-white p-4 rounded-xl shadow-md border-b-4 border-slate-800">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Completion</p>
          <div className="flex items-center space-x-2">
            <p className="text-2xl font-black text-slate-800">{stats.completionRate}%</p>
            <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500" style={{ width: `${stats.completionRate}%` }}></div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-lg border border-slate-100">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
          <div>
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Fitness Performance</h2>
            <p className="text-slate-500 text-sm italic">Showing {viewMode === 'baseline' ? 'Baseline (Initial)' : 'Final (Progress)'} Data</p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
             <div className="relative">
                <button 
                  onClick={() => setShowImportDropdown(!showImportDropdown)}
                  className="bg-slate-800 text-white px-5 py-2.5 rounded-lg text-sm font-black flex items-center shadow-lg transition-all hover:bg-slate-700"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                  {isImporting ? 'Processing...' : 'Bulk Import'}
                </button>
                {showImportDropdown && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowImportDropdown(false)}></div>
                    <div className="absolute right-0 top-full mt-2 w-48 bg-white border border-slate-200 rounded-xl shadow-2xl z-50 overflow-hidden animate-slide-in-fade">
                      <label className="block px-4 py-3 text-xs font-black uppercase text-slate-600 hover:bg-indigo-50 cursor-pointer transition-colors border-b">
                        Import Baseline
                        <input type="file" className="hidden" accept=".xlsx,.xls" onChange={(e) => handleImportFitness(e, 'baseline')} />
                      </label>
                      <label className="block px-4 py-3 text-xs font-black uppercase text-slate-600 hover:bg-emerald-50 cursor-pointer transition-colors">
                        Import Final Test
                        <input type="file" className="hidden" accept=".xlsx,.xls" onChange={(e) => handleImportFitness(e, 'final')} />
                      </label>
                    </div>
                  </>
                )}
             </div>

            <button 
              onClick={() => openAnalysis('Physical Development Analytics')}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg text-sm font-black flex items-center shadow-lg transition-all"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
              Compare Analytics
            </button>

            <button 
              onClick={() => openAnalysis('Student Progress Reports')}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-lg text-sm font-black flex items-center shadow-lg transition-all"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2a4 4 0 10-8 0v2m8-2a4 4 0 11-8 0m8 2v1a2 2 0 01-2 2H3a2 2 0 01-2-2v-1m14-5l4-4m0 0l-4-4m4 4H9" /></svg>
              Batch Reports
            </button>

            <button 
              onClick={() => setIsFormOpen(true)}
              className="bg-slate-900 hover:bg-black text-white px-5 py-2.5 rounded-lg text-sm font-black flex items-center shadow-lg transition-all active:scale-95"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
              </svg>
              New Test
            </button>

            <div className="flex bg-slate-100 p-1 rounded-md">
              <button 
                onClick={() => setViewMode('baseline')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${viewMode === 'baseline' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Baseline
              </button>
              <button 
                onClick={() => setViewMode('final')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-all ${viewMode === 'final' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Final
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-slate-50 rounded-lg">
          <div className="relative">
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">Search (Name or Roll No)</label>
            <input
              type="text"
              placeholder="e.g. susan or 1..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 text-sm border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all shadow-sm"
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">Grade</label>
            <select value={filterClass} onChange={(e) => setFilterClass(e.target.value)} className="w-full px-4 py-2 text-sm border-slate-200 rounded-xl outline-none shadow-sm">
              {availableClasses.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1">Section</label>
            <select value={filterSection} onChange={(e) => setFilterSection(e.target.value)} className="w-full px-4 py-2 text-sm border-slate-200 rounded-xl outline-none shadow-sm">
              {availableSections.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="flex items-end pb-1">
             <button onClick={() => { setFilterClass('All'); setFilterSection('All'); setSearchTerm(''); }} className="text-[10px] text-slate-400 hover:text-rose-500 font-black uppercase tracking-widest px-2 py-2 transition-colors">Reset Filters</button>
          </div>
        </div>

        <div className="overflow-x-auto border border-slate-100 rounded-xl overflow-hidden shadow-sm">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-4 text-left text-xs font-black text-slate-400 uppercase tracking-widest">Roll</th>
                <th className="px-4 py-4 text-left text-xs font-black text-slate-400 uppercase tracking-widest">Student</th>
                <th className="px-4 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">50m/600m</th>
                <th className="px-4 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">HT/WT/BMI</th>
                <th className="px-4 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">Total</th>
                <th className="px-4 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">Grade</th>
                <th className="px-4 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">View</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-100">
              {filteredRecords.length > 0 ? (
                filteredRecords.map((record) => {
                  const metrics = viewMode === 'baseline' ? record.baseline : (record.final || record.baseline);
                  return (
                    <tr key={`${record.class}-${record.section}-${record.rollNo}-${record.name}`} className="hover:bg-indigo-50/20 transition-all group">
                      <td className="px-4 py-4 text-sm font-bold text-slate-400">{record.rollNo}</td>
                      <td className="px-4 py-4">
                        <div className="text-sm font-black text-slate-800">{record.name}</div>
                        <div className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{record.class} • {record.section}</div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="text-xs font-black text-slate-600 bg-slate-100 py-1 px-2 rounded-full inline-block">{metrics.speed50m} <span className="text-slate-400 mx-1">/</span> {metrics.endurance600m} <span className="text-slate-300 ml-1 text-[8px]">pts</span></div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <div className="text-[9px] font-black text-slate-500 uppercase">{metrics.height}cm • {metrics.weight}kg • {metrics.bmi}bmi</div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className="text-lg font-black text-slate-800 tracking-tighter">{metrics.total}</span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <span className={`inline-flex items-center px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                          metrics.grade === 'A' ? 'bg-indigo-100 text-indigo-700' :
                          metrics.grade === 'B' ? 'bg-emerald-100 text-emerald-700' :
                          metrics.grade === 'C' ? 'bg-amber-100 text-amber-700' :
                          'bg-rose-100 text-rose-700'
                        }`}>
                          {metrics.grade}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <button onClick={() => setSelectedRecord(record)} className="p-2 bg-slate-100 rounded-xl text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr><td colSpan={7} className="py-20 text-center text-slate-300 font-bold uppercase tracking-widest text-xs">No matching fitness records found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FitnessTracker;
