
import React, { useMemo } from 'react';
import { DisciplineRecord } from '../types';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface ReportModalProps {
  records: DisciplineRecord[];
  reportType: 'weekly' | 'monthly' | 'custom';
  onClose: () => void;
  onExport: () => void;
  consensusMap?: Record<string, Set<string>>;
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

const ReportModal: React.FC<ReportModalProps> = ({ records, reportType, onClose, onExport, consensusMap }) => {
  // Calculate stats for user activity
  const userStats = useMemo(() => {
    const stats: { [key: string]: number } = {};
    records.forEach(record => {
      const user = record.enteredBy || 'Unknown';
      stats[user] = (stats[user] || 0) + 1;
    });
    return Object.entries(stats).sort((a, b) => b[1] - a[1]);
  }, [records]);

  // Calculate stats for Infraction Types (for Pie Chart)
  const infractionStats = useMemo(() => {
    const stats: { [key: string]: number } = {};
    records.forEach(record => {
      const type = record.infractionType;
      stats[type] = (stats[type] || 0) + 1;
    });
    return Object.keys(stats).map(key => ({ name: key, value: stats[key] }));
  }, [records]);

  let reportTitle = 'Discipline Analytics';
  if (reportType === 'weekly') reportTitle = 'Weekly Activity Report (7 Days)';
  if (reportType === 'monthly') reportTitle = 'Monthly Activity Report (30 Days)';
  if (reportType === 'custom') reportTitle = 'Custom Date Range Analytics';

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-6xl max-h-[95vh] flex flex-col animate-slide-in-fade overflow-hidden border border-slate-200">
        <div className="flex justify-between items-center px-8 py-6 bg-slate-50 border-b border-slate-200">
          <div>
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">{reportTitle}</h2>
            <p className="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Found {records.length} total violation logs</p>
          </div>
          <button onClick={onClose} className="p-2 bg-white rounded-full border border-slate-200 text-slate-400 hover:text-rose-500 hover:border-rose-100 transition-all shadow-sm" aria-label="Close modal">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="overflow-y-auto p-8 flex-1 space-y-8 bg-white">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* User Activity Summary Section */}
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6 flex flex-col">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center">
                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mr-2"></span>
                Staff Participation Overview
              </h3>
              <div className="space-y-3 flex-1 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                {userStats.map(([email, count]) => (
                  <div key={email} className="flex justify-between items-center bg-white p-4 rounded-xl shadow-sm border border-slate-100 hover:border-indigo-200 transition-all">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-slate-400 uppercase font-black tracking-widest">Reporter</span>
                      <span className="text-sm font-black text-slate-700 truncate max-w-[200px]">{email}</span>
                    </div>
                    <div className="text-right">
                       <span className="text-xl font-black text-indigo-600">{count}</span>
                       <span className="text-[9px] text-slate-400 uppercase font-black tracking-widest block">Entries</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pie Chart Section */}
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-6">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center">
                <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mr-2"></span>
                Infraction Breakdown
              </h3>
              <div className="h-[300px] flex items-center justify-center">
                 <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={infractionStats}
                        cx="50%"
                        cy="50%"
                        innerRadius={70}
                        outerRadius={100}
                        fill="#6366f1"
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                      >
                        {infractionStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} 
                      />
                      <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', textTransform: 'uppercase' }}/>
                    </PieChart>
                 </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Detailed Table Section with Multi-Staff Highlights */}
          <div className="bg-white">
             <div className="flex justify-between items-end mb-4">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center">
                  <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mr-2"></span>
                  Detailed Audit Logs
                </h3>
                <div className="flex items-center gap-2">
                   <span className="w-2 h-2 bg-indigo-600 rounded-sm"></span>
                   <span className="text-[8px] font-black text-slate-400 uppercase">Highlights Staff Consensus</span>
                </div>
             </div>
             <div className="border rounded-2xl overflow-hidden border-slate-200 shadow-sm">
              <div className="overflow-x-auto max-h-[400px]">
                <table className="min-w-full divide-y divide-slate-200">
                  <thead className="bg-slate-50 sticky top-0 z-10">
                    <tr>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Teacher (Lead)</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Student</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Type</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Co-Reporters</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-slate-400 uppercase tracking-widest">Date</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-100">
                    {records.map((record) => {
                      const key = `${record.studentName.toLowerCase()}|${record.infractionType}|${record.date}`;
                      const allReporters = consensusMap ? Array.from(consensusMap[key] || []) : [];
                      const coReporters = allReporters.filter(email => email !== record.enteredBy);
                      const isConsensus = coReporters.length > 0;

                      return (
                        <tr key={record.id} className={`hover:bg-indigo-50/30 transition-colors ${isConsensus ? 'bg-indigo-50/10' : ''}`}>
                          <td className="px-6 py-4 whitespace-nowrap text-xs text-indigo-600 font-black">
                             {record.enteredBy.split('@')[0]}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <p className="text-sm font-black text-slate-800">{record.studentName}</p>
                            <p className="text-[9px] font-bold text-slate-400 uppercase">Grade {record.grade}</p>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider ${isConsensus ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                              {record.infractionType}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {isConsensus ? (
                               <div className="flex -space-x-1">
                                  {coReporters.map((email, idx) => (
                                    <div key={idx} className="h-5 w-5 bg-indigo-100 border border-white rounded-full flex items-center justify-center text-[8px] font-black text-indigo-700" title={email}>
                                       {email.charAt(0).toUpperCase()}
                                    </div>
                                  ))}
                               </div>
                            ) : (
                               <span className="text-[9px] text-slate-300 font-bold uppercase tracking-widest">Only Record</span>
                            )}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-xs font-bold text-slate-500">{record.date}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end items-center px-8 py-6 border-t border-slate-200 space-x-3 bg-slate-50">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-white border border-slate-300 text-xs font-black uppercase tracking-widest rounded-xl text-slate-500 hover:bg-slate-100 transition-all shadow-sm"
          >
            Cancel
          </button>
          <button
            onClick={onExport}
            className="inline-flex items-center justify-center px-8 py-2.5 bg-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-xl hover:bg-indigo-700 transition-all shadow-lg active:scale-95"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Download Data (Excel)
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReportModal;
