
import { FitnessRecord } from '../types';

export const fitnessRecords: FitnessRecord[] = [
  // Class III A
  {
    rollNo: 1, name: 'AADHIYA SUSAN SANTHEEP', class: 'III', section: 'A',
    // Mapping legacy fields to satisfy FitnessMetrics required properties and fix gameSkill3 error
    baseline: { height: 102, weight: 19, bmi: 18.26, strength: 6, speed50m: 7, endurance600m: 6, flexibility: 0, gameSkill1: 0, gameSkill2: 35, curlsUp: 0, discipline: 20, total: 74, grade: 'C', remark: '' },
    final: { height: 104, weight: 20, bmi: 18.5, strength: 7, speed50m: 8, endurance600m: 7, flexibility: 2, gameSkill1: 5, gameSkill2: 40, curlsUp: 5, discipline: 20, total: 84, grade: 'B', remark: 'Improved' }
  },
  {
    rollNo: 2, name: 'AADIL AHMED M', class: 'III', section: 'A',
    baseline: { height: 0, weight: 25, bmi: 0, strength: 9, speed50m: 10, endurance600m: 10, flexibility: 0, gameSkill1: 0, gameSkill2: 50, curlsUp: 0, discipline: 15, total: 94, grade: 'A', remark: '' }
  },
  {
    rollNo: 3, name: 'ADVIK SAI SHASVANTH V', class: 'III', section: 'A',
    baseline: { height: 0, weight: 19, bmi: 0, strength: 5, speed50m: 7, endurance600m: 6, flexibility: 0, gameSkill1: 0, gameSkill2: 40, curlsUp: 0, discipline: 15, total: 73, grade: 'C', remark: '' }
  },
  {
    rollNo: 4, name: 'AGNIKAA VARSHINI A', class: 'III', section: 'A',
    baseline: { height: 0, weight: 19, bmi: 0, strength: 6, speed50m: 10, endurance600m: 7, flexibility: 0, gameSkill1: 0, gameSkill2: 47, curlsUp: 0, discipline: 10, total: 80, grade: 'B', remark: '' }
  },
  {
    rollNo: 5, name: 'AKSHAY A', class: 'III', section: 'A',
    baseline: { height: 0, weight: 21, bmi: 0, strength: 8, speed50m: 10, endurance600m: 10, flexibility: 0, gameSkill1: 0, gameSkill2: 48, curlsUp: 0, discipline: 20, total: 96, grade: 'A', remark: '' }
  },
  {
    rollNo: 6, name: 'CYRILLA A', class: 'III', section: 'A',
    baseline: { height: 0, weight: 39, bmi: 0, strength: 6, speed50m: 7, endurance600m: 5, flexibility: 10, gameSkill1: 15, gameSkill2: 35, curlsUp: 15, discipline: 15, total: 68, grade: 'C', remark: '' }
  },
  {
    rollNo: 7, name: 'DAANIA NAVEEN', class: 'III', section: 'A',
    baseline: { height: 0, weight: 36, bmi: 0, strength: 6, speed50m: 6, endurance600m: 5, flexibility: 0, gameSkill1: 0, gameSkill2: 20, curlsUp: 0, discipline: 10, total: 47, grade: 'D', remark: '' }
  },
  {
    rollNo: 8, name: 'DHAKSHAN G A', class: 'III', section: 'A',
    baseline: { height: 0, weight: 20, bmi: 0, strength: 9, speed50m: 10, endurance600m: 10, flexibility: 0, gameSkill1: 0, gameSkill2: 45, curlsUp: 0, discipline: 15, total: 89, grade: 'B', remark: '' }
  },
  {
    rollNo: 11, name: 'HARSHITH B', class: 'III', section: 'A',
    baseline: { height: 0, weight: 20, bmi: 0, strength: 8, speed50m: 9, endurance600m: 10, flexibility: 0, gameSkill1: 0, gameSkill2: 45, curlsUp: 0, discipline: 18, total: 90, grade: 'A', remark: '' }
  },
  // Class III B
  {
    rollNo: 1, name: 'ADITHI ABISHA', class: 'III', section: 'B',
    baseline: { height: 0, weight: 25, bmi: 0, strength: 6, speed50m: 10, endurance600m: 6, flexibility: 0, gameSkill1: 0, gameSkill2: 35, curlsUp: 0, discipline: 17, total: 74, grade: 'C', remark: '' }
  },
  {
    rollNo: 13, name: 'MAGUDAVATHANI V', class: 'III', section: 'B',
    baseline: { height: 0, weight: 17, bmi: 0, strength: 9, speed50m: 10, endurance600m: 9, flexibility: 0, gameSkill1: 0, gameSkill2: 47, curlsUp: 0, discipline: 19, total: 94, grade: 'A', remark: '' }
  },
  // Class III C
  {
    rollNo: 3, name: 'AISHWARIYA SRINIVSAN', class: 'III', section: 'C',
    baseline: { height: 0, weight: 23, bmi: 0, strength: 9, speed50m: 9, endurance600m: 9, flexibility: 0, gameSkill1: 0, gameSkill2: 45, curlsUp: 0, discipline: 18, total: 90, grade: 'A', remark: '' }
  },
  {
    rollNo: 24, name: 'TRISHITHA S P', class: 'III', section: 'C',
    baseline: { height: 0, weight: 26, bmi: 0, strength: 10, speed50m: 10, endurance600m: 10, flexibility: 0, gameSkill1: 0, gameSkill2: 48, curlsUp: 0, discipline: 18, total: 96, grade: 'A', remark: '' }
  }
];
