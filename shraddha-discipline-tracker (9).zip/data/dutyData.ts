
import { DutyAssignment } from '../types';

export const initialDutyRoster: DutyAssignment[] = [
  // MONDAY
  { id: 'm1', day: 'Monday', type: 'Snack', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'm2', day: 'Monday', type: 'Snack', location: 'First floor', teacherName: 'Chitra' },
  { id: 'm3', day: 'Monday', type: 'Snack', location: 'Second floor', teacherName: 'Fathima Acc' },
  { id: 'm4', day: 'Monday', type: 'Snack', location: 'Canteen area', teacherName: 'Raynu' },
  { id: 'm5', day: 'Monday', type: 'Lunch', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'm6', day: 'Monday', type: 'Lunch', location: 'First floor', teacherName: 'Fathima' },
  { id: 'm7', day: 'Monday', type: 'Lunch', location: 'Second floor', teacherName: 'Magesh' },
  { id: 'm8', day: 'Monday', type: 'Lunch', location: 'Canteen area', teacherName: 'Prem', phoneNumber: '919840214056' },
  { id: 'm9', day: 'Monday', type: 'Dispersal', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'm10', day: 'Monday', type: 'Dispersal', location: 'First floor', teacherName: 'Elfin' },
  { id: 'm11', day: 'Monday', type: 'Dispersal', location: 'Second floor', teacherName: 'Juliet' },
  { id: 'm12', day: 'Monday', type: 'Dispersal', location: 'Dispersal area', teacherName: 'Bala', phoneNumber: '919677333404' },

  // TUESDAY
  { id: 't1', day: 'Tuesday', type: 'Snack', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 't2', day: 'Tuesday', type: 'Snack', location: 'First floor', teacherName: 'Sanu' },
  { id: 't3', day: 'Tuesday', type: 'Snack', location: 'Second floor', teacherName: 'Sathyadevi' },
  { id: 't4', day: 'Tuesday', type: 'Snack', location: 'Canteen area', teacherName: 'Fathima Acc' },
  { id: 't5', day: 'Tuesday', type: 'Lunch', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 't6', day: 'Tuesday', type: 'Lunch', location: 'First floor', teacherName: 'Rajitha' },
  { id: 't7', day: 'Tuesday', type: 'Lunch', location: 'Second floor', teacherName: 'Fredric' },
  { id: 't8', day: 'Tuesday', type: 'Lunch', location: 'Canteen area', teacherName: 'Srinivas' },
  { id: 't9', day: 'Tuesday', type: 'Dispersal', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 't10', day: 'Tuesday', type: 'Dispersal', location: 'First floor', teacherName: 'Sasikala' },
  { id: 't11', day: 'Tuesday', type: 'Dispersal', location: 'Second floor', teacherName: 'Swapna' },
  { id: 't12', day: 'Tuesday', type: 'Dispersal', location: 'Dispersal area', teacherName: 'Chitra' },

  // WEDNESDAY
  { id: 'w1', day: 'Wednesday', type: 'Snack', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'w2', day: 'Wednesday', type: 'Snack', location: 'First floor', teacherName: 'Uma' },
  { id: 'w3', day: 'Wednesday', type: 'Snack', location: 'Second floor', teacherName: 'Vandana' },
  { id: 'w4', day: 'Wednesday', type: 'Snack', location: 'Canteen area', teacherName: 'Fredric' },
  { id: 'w5', day: 'Wednesday', type: 'Lunch', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'w6', day: 'Wednesday', type: 'Lunch', location: 'First floor', teacherName: 'Prem Kumar' },
  { id: 'w7', day: 'Wednesday', type: 'Lunch', location: 'Second floor', teacherName: 'Leena W' },
  { id: 'w8', day: 'Wednesday', type: 'Lunch', location: 'Canteen area', teacherName: 'Annapoorna' },
  { id: 'w9', day: 'Wednesday', type: 'Dispersal', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'w10', day: 'Wednesday', type: 'Dispersal', location: 'First floor', teacherName: 'Saravana Perumal' },
  { id: 'w11', day: 'Wednesday', type: 'Dispersal', location: 'Second floor', teacherName: 'Rathnamala' },
  { id: 'w12', day: 'Wednesday', type: 'Dispersal', location: 'Dispersal area', teacherName: 'Samuel' },

  // THURSDAY
  { id: 'th1', day: 'Thursday', type: 'Snack', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'th2', day: 'Thursday', type: 'Snack', location: 'First floor', teacherName: 'Tejeshwi' },
  { id: 'th3', day: 'Thursday', type: 'Snack', location: 'Second floor', teacherName: 'Radha' },
  { id: 'th4', day: 'Thursday', type: 'Snack', location: 'Canteen area', teacherName: 'Hema' },
  { id: 'th5', day: 'Thursday', type: 'Lunch', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'th6', day: 'Thursday', type: 'Lunch', location: 'First floor', teacherName: 'Maneesha' },
  { id: 'th7', day: 'Thursday', type: 'Lunch', location: 'Second floor', teacherName: 'Lima' },
  { id: 'th8', day: 'Thursday', type: 'Lunch', location: 'Canteen area', teacherName: 'Murugan' },
  { id: 'th9', day: 'Thursday', type: 'Dispersal', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'th10', day: 'Thursday', type: 'Dispersal', location: 'First floor', teacherName: 'Uma' },
  { id: 'th11', day: 'Thursday', type: 'Dispersal', location: 'Second floor', teacherName: 'Subha' },
  { id: 'th12', day: 'Thursday', type: 'Dispersal', location: 'Dispersal area', teacherName: 'Raynu' },

  // FRIDAY
  { id: 'f1', day: 'Friday', type: 'Snack', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'f2', day: 'Friday', type: 'Snack', location: 'First floor', teacherName: 'Malathy' },
  { id: 'f3', day: 'Friday', type: 'Snack', location: 'Second floor', teacherName: 'Pavithra' },
  { id: 'f4', day: 'Friday', type: 'Snack', location: 'Canteen area', teacherName: 'Hema' },
  { id: 'f5', day: 'Friday', type: 'Lunch', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'f6', day: 'Friday', type: 'Lunch', location: 'First floor', teacherName: 'Shivdevi' },
  { id: 'f7', day: 'Friday', type: 'Lunch', location: 'Second floor', teacherName: 'Juliet' },
  { id: 'f8', day: 'Friday', type: 'Lunch', location: 'Canteen area', teacherName: 'Preetha' },
  { id: 'f9', day: 'Friday', type: 'Dispersal', location: 'Ground floor', teacherName: 'Class teacher' },
  { id: 'f10', day: 'Friday', type: 'Dispersal', location: 'First floor', teacherName: 'Gita' },
  { id: 'f11', day: 'Friday', type: 'Dispersal', location: 'Second floor', teacherName: 'Sangamitra' },
  { id: 'f12', day: 'Friday', type: 'Dispersal', location: 'Dispersal area', teacherName: 'Jonathan' },
];
