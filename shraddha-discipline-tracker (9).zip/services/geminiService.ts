
import { GoogleGenAI } from "@google/genai";
import { DisciplineRecord } from '../types';

const generateDisciplineNote = async (record: DisciplineRecord): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API key not configured.";
  }
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      You are an assistant for a school principal. Write a polite, firm, and professional note for parents about a discipline issue.
      Issue: ${record.infractionType}
      Student: ${record.studentName}
      Grade: ${record.grade}
      Date: ${record.date}
      Details: ${record.notes}
      Signed: Shraddha School Administration
    `;
    
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
    });

    return response.text ?? "Unable to generate note.";
  } catch (error) {
    console.error("Error:", error);
    return "Failed to generate note.";
  }
};

export default generateDisciplineNote;
