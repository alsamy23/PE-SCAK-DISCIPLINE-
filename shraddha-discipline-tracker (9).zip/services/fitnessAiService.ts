
import { GoogleGenAI } from "@google/genai";

export const analyzeClassFitness = async (averages: { metric: string, baseline: number, final: number }[]): Promise<string> => {
  if (!process.env.API_KEY) return "AI Insights unavailable (API Key missing).";

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const dataSummary = averages.map(a => 
      `${a.metric}: Baseline Avg ${a.baseline.toFixed(1)}, Final Avg ${a.final.toFixed(1)} (Diff: ${(a.final - a.baseline).toFixed(1)})`
    ).join('\n');

    const prompt = `
      As a Senior PE Coach and Sports Scientist, analyze the following fitness data averages for a class.
      The metrics are based on a 10-20 point scale.
      
      Data:
      ${dataSummary}
      
      Provide a concise 3-sentence professional summary:
      1. Overall class improvement trend.
      2. The metric with the most significant growth.
      3. A specific training recommendation for the upcoming term based on the weakest areas.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text ?? "Unable to analyze trends.";
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return "Error generating class insights.";
  }
};
