
import { initializeApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  doc, 
  setDoc, 
  deleteDoc,
  writeBatch
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN,
  projectId: process.env.FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID
};

const isConfigured = !!firebaseConfig.projectId;
const app = isConfigured ? initializeApp(firebaseConfig) : null;
export const db = app ? getFirestore(app) : null;

export const isFirebaseActive = () => !!db;

export const syncStudents = async (students: any[]) => {
  if (!db) return;
  const batch = writeBatch(db);
  students.forEach((student, index) => {
    const studentRef = doc(collection(db, "students"), student.id || `std-${index}`);
    batch.set(studentRef, student);
  });
  await batch.commit();
};

export const addDisciplineRecord = async (record: any) => {
  if (!db) return;
  return await addDoc(collection(db, "discipline_records"), record);
};

export const saveFitnessRecord = async (record: any) => {
  if (!db) return;
  const id = `${record.class}-${record.section}-${record.rollNo}`.replace(/\s+/g, '-');
  const recordRef = doc(db, "fitness_records", id);
  await setDoc(recordRef, record, { merge: true });
};

export const saveRestriction = async (restriction: any) => {
  if (!db) return;
  const id = restriction.id || `res-${Date.now()}`;
  const ref = doc(db, "restrictions", id);
  await setDoc(ref, { ...restriction, id }, { merge: true });
};

export const deleteRestriction = async (id: string) => {
  if (!db) return;
  await deleteDoc(doc(db, "restrictions", id));
};
